'use strict';
// FR-01 (Aarya): register / login / profile.
// Issues the JWT that middleware/auth.js verifies: HS256, payload { user_id }.
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config');
const { query } = require('../db');
const v = require('../validators');
const { AppError } = require('../errors');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const sign = (userId) => jwt.sign({ user_id: userId }, config.jwtSecret, { algorithm: 'HS256', expiresIn: '8h' });
const PHONE_RE = /^[0-9]{10}$/;               // exactly 10 digits
const publicUser = (u) => ({ user_id: u.user_id, name: u.name, email: u.email, phone: u.phone, role: u.role });

// POST /api/auth/register { name, email, phone, password }   (phone = exactly 10 digits; new accounts are always role USER -
// the one and only ADMIN account exists in the database and cannot be created through the API)
router.post('/register', asyncHandler(async (req, res) => {
  const b = v.body(req);
  const name = v.string(b.name, 'name', { min: 2, max: 100 });
  const email = v.string(b.email, 'email', { max: 150 }).toLowerCase();
  const phone = v.string(b.phone, 'phone', { min: 10, max: 10 });
  const password = v.string(b.password, 'password', { min: 8, max: 100 });
  if (name.includes('@')) v.fail('name', 'must not contain @ (the name is also used as a login id)');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) v.fail('email', 'is not a valid email address');
  if (!PHONE_RE.test(phone)) v.fail('phone', 'must be exactly 10 digits');
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) v.fail('password', 'needs at least one letter and one number');

  // the name doubles as a login id, so it must be unique (case-insensitive)
  const same = await query('SELECT user_id FROM users WHERE LOWER(name) = LOWER(?)', [name]);
  if (same.length) throw new AppError(409, 'DUPLICATE_ENTRY', 'This name is already taken. Please choose another one');

  const hash = await bcrypt.hash(password, 10);                  // never store plain passwords
  const r = await query(`INSERT INTO users (name, email, phone, password_hash, role) VALUES (?,?,?,?,'USER')`, [name, email, phone, hash]);
  const user = { user_id: r.insertId, name, email, phone, role: 'USER' };
  res.status(201).json({ success: true, data: { token: sign(user.user_id), user } });
}));

// POST /api/auth/login { login, password }   login = email OR name (e.g. HARRY)
router.post('/login', asyncHandler(async (req, res) => {
  const b = v.body(req);
  const login = v.string(b.login ?? b.email, 'login', { max: 150 });
  const password = v.string(b.password, 'password', { max: 100 });
  const rows = login.includes('@')
    ? await query('SELECT * FROM users WHERE email = ?', [login.toLowerCase()])
    : await query('SELECT * FROM users WHERE LOWER(name) = LOWER(?)', [login]);
  // same message for "no such user" and "wrong password"
  const bad = new AppError(401, 'INVALID_CREDENTIALS', 'Invalid login or password');
  if (rows.length !== 1 || !rows[0].is_active) throw bad;
  if (!(await bcrypt.compare(password, rows[0].password_hash))) throw bad;
  // The user site and the admin site are separate: each one only accepts its own kind of account.
  // (checked AFTER the password so the existence of an account is never revealed)
  if (b.portal === 'admin' && rows[0].role !== 'ADMIN') throw new AppError(403, 'NOT_ADMIN', 'This is not an administrator account');
  if (b.portal === 'user' && rows[0].role === 'ADMIN') throw new AppError(403, 'ADMIN_USE_ADMIN_PORTAL', 'Administrator accounts must log in at the admin site (/admin/)');
  res.json({ success: true, data: { token: sign(rows[0].user_id), user: publicUser(rows[0]) } });
}));

router.get('/me', authenticate, asyncHandler(async (req, res) => {
  const rows = await query('SELECT user_id, name, email, phone, role, created_at FROM users WHERE user_id = ?', [req.user.id]);
  res.json({ success: true, data: rows[0] });
}));

// PUT /api/auth/me { name, phone }
router.put('/me', authenticate, asyncHandler(async (req, res) => {
  const b = v.body(req);
  const name = v.string(b.name, 'name', { min: 2, max: 100 });
  const phone = v.string(b.phone, 'phone', { min: 10, max: 10 });
  if (name.includes('@')) v.fail('name', 'must not contain @ (the name is also used as a login id)');
  if (!PHONE_RE.test(phone)) v.fail('phone', 'must be exactly 10 digits');
  const same = await query('SELECT user_id FROM users WHERE LOWER(name) = LOWER(?) AND user_id <> ?', [name, req.user.id]);
  if (same.length) throw new AppError(409, 'DUPLICATE_ENTRY', 'This name is already taken');
  await query('UPDATE users SET name = ?, phone = ? WHERE user_id = ?', [name, phone, req.user.id]);
  res.json({ success: true, message: 'Profile updated', data: { name, phone } });
}));

module.exports = router;
