'use strict';
// Admin portal: everything the administrator can see about users and money, plus PDF reports.
const router = require('express').Router();
const v = require('../validators');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { query } = require('../db');
const reports = require('../services/reportService');

router.use(authenticate, requireAdmin);
const ok = (res, data, extra = {}) => res.json({ success: true, data, ...extra });

function sendPdf(res, buffer, filename) {
  res.set({
    'Content-Type': 'application/pdf',
    'Content-Length': buffer.length,
    'Content-Disposition': `attachment; filename="${filename}"`,
    'Cache-Control': 'no-store',
  });
  res.end(buffer);
}
const safe = (s) => String(s).replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40) || 'user';

// GET /api/admin/users?q=       every registered user with booking / energy / money totals
router.get('/users', asyncHandler(async (req, res) => ok(res, await reports.userList(req.query.q))));

// GET /api/admin/users/:id/report        complete information about one user (JSON)
router.get('/users/:id/report', asyncHandler(async (req, res) => ok(res, await reports.userReport(v.id(req.params.id, 'id')))));

// GET /api/admin/users/:id/report/pdf    the same information as a PDF, one file per user
router.get('/users/:id/report/pdf', asyncHandler(async (req, res) => {
  const rep = await reports.userReport(v.id(req.params.id, 'id'));
  sendPdf(res, reports.userReportPdf(rep), `VoltSlot_user_${rep.user.user_id}_${safe(rep.user.name)}.pdf`);
}));

// GET /api/admin/reports/users-summary/pdf    one-page-per-table summary of all users
router.get('/reports/users-summary/pdf', asyncHandler(async (_req, res) => {
  const users = await reports.userList();
  const [{ now }] = await query("SELECT DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') AS now");
  sendPdf(res, reports.usersSummaryPdf(users, now), 'VoltSlot_all_users_summary.pdf');
}));

// GET /api/admin/payments?status=PAID|PENDING     every bill with user and station
router.get('/payments', asyncHandler(async (req, res) => {
  const status = req.query.status === undefined || req.query.status === '' ? undefined
    : v.oneOf(req.query.status, 'status', ['PENDING', 'PAID', 'REFUNDED', 'FAILED']);
  const { limit, offset } = v.pagination(req.query);
  const where = status ? 'WHERE payment_status = ?' : '';
  const p = status ? [status] : [];
  const rows = await query(
    `SELECT booking_id, user_id, user_name, station_name, slot_start, payment_amount AS amount, payment_status AS status,
            payment_method AS method, transaction_ref, payment_paid_at AS paid_at, energy_kwh
       FROM User_Booking_History_View ${where.length ? where + ' AND' : 'WHERE'} payment_status IS NOT NULL
      ORDER BY booking_id DESC LIMIT ? OFFSET ?`, [...p, limit, offset]);
  ok(res, rows);
}));

// GET /api/admin/finance     money and usage totals for the dashboard
router.get('/finance', asyncHandler(async (_req, res) => {
  const [t] = await query(
    `SELECT (SELECT COUNT(*) FROM users WHERE role = 'USER')                                AS users,
            COALESCE(SUM(CASE WHEN status = 'PAID' THEN amount END), 0)                     AS paid_total,
            COALESCE(SUM(CASE WHEN status = 'PENDING' THEN amount END), 0)                  AS pending_total,
            COALESCE(SUM(status = 'PAID'), 0)                                               AS paid_count,
            COALESCE(SUM(status = 'PENDING'), 0)                                            AS pending_count,
            (SELECT COALESCE(SUM(energy_kwh), 0) FROM charging_session WHERE status = 'COMPLETED') AS energy_kwh
       FROM payment`);
  const byMethod = await query(
    `SELECT method, COUNT(*) AS payments, SUM(amount) AS amount FROM payment WHERE status = 'PAID' GROUP BY method ORDER BY amount DESC`);
  ok(res, { ...t, by_method: byMethod });
}));

module.exports = router;
