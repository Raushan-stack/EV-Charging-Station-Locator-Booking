'use strict';
// In-app notifications for the logged-in user (rows are created by database triggers).
//   GET  /api/notifications?limit=30   newest first, plus the number of unread messages
//   POST /api/notifications/read       { ids: [1,2] }  or no body = mark everything as read
const router = require('express').Router();
const v = require('../validators');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { query } = require('../db');

router.use(authenticate);

router.get('/', asyncHandler(async (req, res) => {
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 30, 1), 100);
  const rows = await query(
    `SELECT notification_id, booking_id, type, title, message, is_read, created_at
       FROM notification WHERE user_id = ? ORDER BY notification_id DESC LIMIT ?`, [req.user.id, limit]);
  const [{ unread }] = await query('SELECT COUNT(*) AS unread FROM notification WHERE user_id = ? AND is_read = 0', [req.user.id]);
  res.json({ success: true, data: rows, meta: { unread } });
}));

router.post('/read', asyncHandler(async (req, res) => {
  const body = req.body || {};
  if (Array.isArray(body.ids) && body.ids.length) {
    const ids = body.ids.slice(0, 100).map((x) => v.id(x, 'id'));
    await query(`UPDATE notification SET is_read = 1 WHERE user_id = ? AND notification_id IN (${ids.map(() => '?').join(',')})`, [req.user.id, ...ids]);
  } else {
    await query('UPDATE notification SET is_read = 1 WHERE user_id = ? AND is_read = 0', [req.user.id]);
  }
  res.json({ success: true, message: 'Marked as read' });
}));

module.exports = router;
