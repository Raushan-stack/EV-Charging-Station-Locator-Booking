'use strict';
// User portal extras:
//   PUT  /api/trip/bookings/:id/battery   save the driver's battery plan for a booking
//   POST /api/trip/bookings/:id/pay       pay the bill of a finished charging session
//   GET  /api/trip/summary                totals for the logged-in user (dashboard tiles)
const router = require('express').Router();
const crypto = require('crypto');
const v = require('../validators');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { AppError } = require('../errors');
const { query, withTransaction } = require('../db');

router.use(authenticate);

const METHODS = ['UPI', 'CARD', 'NETBANKING', 'CASH'];

// ---- battery plan (saved right after a booking is confirmed) --------------------
router.put('/bookings/:id/battery', asyncHandler(async (req, res) => {
  const id = v.id(req.params.id, 'id');
  const b = v.body(req);
  const start = v.integer(b.battery_start_pct, 'battery_start_pct', { min: 0, max: 99 });
  const target = v.integer(b.battery_target_pct, 'battery_target_pct', { min: 1, max: 100 });
  const capacity = v.number(b.battery_capacity_kwh, 'battery_capacity_kwh', { min: 0, exclusiveMin: true, max: 500 });
  if (target <= start) v.fail('battery_target_pct', 'must be higher than the current battery level');

  const rows = await query('SELECT user_id, status FROM booking WHERE booking_id = ?', [id]);
  if (!rows.length || rows[0].user_id !== req.user.id) throw new AppError(404, 'BOOKING_NOT_FOUND', 'Booking not found');
  if (!['CONFIRMED', 'IN_PROGRESS'].includes(rows[0].status)) throw new AppError(409, 'INVALID_STATE', 'The battery plan can only be set on an active booking');

  await query('UPDATE booking SET battery_start_pct = ?, battery_target_pct = ?, battery_capacity_kwh = ? WHERE booking_id = ?',
    [start, target, capacity, id]);
  res.json({ success: true, message: 'Battery plan saved', data: { booking_id: id, battery_start_pct: start, battery_target_pct: target, battery_capacity_kwh: capacity } });
}));

// ---- payment ----------------------------------------------------------------------
// A PENDING payment is created automatically when charging ends (sp_end_session).
// Paying it is one small transaction: lock the payment row, check owner and state, mark it PAID.
router.post('/bookings/:id/pay', asyncHandler(async (req, res) => {
  const id = v.id(req.params.id, 'id');
  const method = v.oneOf(v.body(req).method, 'method', METHODS);

  const out = await withTransaction(async (conn) => {
    const [rows] = await conn.query(
      `SELECT p.payment_id, p.amount, p.status, p.transaction_ref, b.user_id
         FROM payment p JOIN booking b ON b.booking_id = p.booking_id
        WHERE p.booking_id = ? FOR UPDATE`, [id]);
    if (!rows.length || rows[0].user_id !== req.user.id) throw new AppError(404, 'PAYMENT_NOT_FOUND', 'There is no bill for this booking yet');
    const p = rows[0];
    if (p.status === 'PAID') throw new AppError(409, 'ALREADY_PAID', 'This bill is already paid');
    if (p.status !== 'PENDING') throw new AppError(409, 'INVALID_STATE', `This payment is ${p.status} and cannot be paid`);
    await conn.query(`UPDATE payment SET status = 'PAID', method = ?, paid_at = NOW() WHERE payment_id = ?`, [method, p.payment_id]);
    return { booking_id: id, amount: p.amount, status: 'PAID', method, transaction_ref: p.transaction_ref };
  });
  res.json({ success: true, message: 'Payment successful', data: out });
}));

// ---- dashboard totals -----------------------------------------------------------
router.get('/summary', asyncHandler(async (req, res) => {
  const [r] = await query(
    `SELECT COUNT(*)                                                          AS bookings,
            COALESCE(SUM(booking_status = 'COMPLETED'), 0)                    AS completed,
            COALESCE(SUM(booking_status IN ('CONFIRMED','IN_PROGRESS')), 0)   AS active,
            COALESCE(SUM(CASE WHEN session_status = 'COMPLETED' THEN energy_kwh END), 0) AS energy_kwh,
            COALESCE(SUM(CASE WHEN payment_status = 'PAID' THEN payment_amount END), 0)    AS paid_amount,
            COALESCE(SUM(CASE WHEN payment_status = 'PENDING' THEN payment_amount END), 0) AS due_amount
       FROM User_Booking_History_View WHERE user_id = ?`, [req.user.id]);
  res.json({ success: true, data: r });
}));

module.exports = router;
