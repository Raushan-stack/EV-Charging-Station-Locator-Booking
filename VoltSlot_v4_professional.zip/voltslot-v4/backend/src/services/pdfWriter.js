'use strict';
// Small dependency-free PDF writer (A4, Helvetica / Helvetica-Bold) used for the admin reports.
// Text metrics for printable ASCII are the standard Helvetica AFM widths (units per 1000 pt).
const W = {
  F1: [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584],
  F2: [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584],
};
const PAGE_W = 595.28, PAGE_H = 841.89;

// Standard fonts cannot show every character: map the common ones, replace the rest with '?'.
function clean(s) {
  return String(s ?? '')
    .replace(/\u20B9/g, 'Rs.').replace(/[\u2013\u2014\u2212]/g, '-').replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"').replace(/\u2192/g, '->').replace(/\u2026/g, '...')
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/[^\x20-\x7E]/g, '?');
}
function width(str, size, font = 'F1') {
  let w = 0;
  for (const ch of str) w += W[font][ch.charCodeAt(0) - 32] || 500;
  return (w * size) / 1000;
}
// Word-wraps text to maxW points; very long words are broken by character.
function wrap(str, maxW, size, font = 'F1') {
  const words = clean(str).split(' ').filter((x) => x.length);
  const lines = []; let cur = '';
  const push = () => { if (cur) lines.push(cur); cur = ''; };
  for (let w of words) {
    while (width(w, size, font) > maxW) {                   // break an over-long word
      let n = 1;
      while (n < w.length && width(w.slice(0, n + 1), size, font) <= maxW) n++;
      push(); lines.push(w.slice(0, n)); w = w.slice(n);
    }
    const t = cur ? cur + ' ' + w : w;
    if (width(t, size, font) <= maxW) cur = t; else { push(); cur = w; }
  }
  push();
  return lines.length ? lines : [''];
}
const esc = (s) => s.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
const num = (n) => (Math.round(n * 100) / 100).toString();
const rgb = (hex) => { const n = parseInt(hex.slice(1), 16); return [(n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255].map((x) => x.toFixed(3)).join(' '); };

class Pdf {
  constructor() { this.pages = []; this.cur = null; }
  addPage() { this.cur = []; this.pages.push(this.cur); return this.cur; }
  // (x, y) = top-left corner, y measured from the TOP of the page
  rect(x, y, w, h, { fill, stroke, lw = 0.6 } = {}) {
    const ops = [];
    if (fill) ops.push(`${rgb(fill)} rg`);
    if (stroke) ops.push(`${rgb(stroke)} RG ${lw} w`);
    ops.push(`${num(x)} ${num(PAGE_H - y - h)} ${num(w)} ${num(h)} re ${fill && stroke ? 'B' : fill ? 'f' : 'S'}`);
    this.cur.push(ops.join(' '));
  }
  line(x1, y1, x2, y2, { stroke = '#C9D3D8', lw = 0.6 } = {}) {
    this.cur.push(`${rgb(stroke)} RG ${lw} w ${num(x1)} ${num(PAGE_H - y1)} m ${num(x2)} ${num(PAGE_H - y2)} l S`);
  }
  // baseline of the text sits at y + size (so y is the top of the text line)
  text(str, x, y, { size = 9, font = 'F1', color = '#0C1A24', align = 'left', maxW } = {}) {
    let t = clean(str);
    if (maxW) while (t.length > 1 && width(t, size, font) > maxW) t = t.slice(0, -1);
    const w = width(t, size, font);
    const px = align === 'right' ? x - w : align === 'center' ? x - w / 2 : x;
    this.cur.push(`BT ${rgb(color)} rg /${font} ${size} Tf ${num(px)} ${num(PAGE_H - y - size)} Td (${esc(t)}) Tj ET`);
  }
  build(meta = {}) {
    const objs = [];                                         // objs[i] = string/Buffer body of object i+1
    objs.push('<< /Type /Catalog /Pages 2 0 R >>');
    const kids = this.pages.map((_, i) => `${5 + i * 2} 0 R`).join(' ');
    objs.push(`<< /Type /Pages /Kids [${kids}] /Count ${this.pages.length} >>`);
    objs.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    objs.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    this.pages.forEach((ops, i) => {
      const stream = Buffer.from(ops.join('\n'), 'latin1');
      objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${6 + i * 2} 0 R >>`);
      objs.push({ stream });
    });
    const info = objs.length + 1;
    objs.push(`<< /Title (${esc(clean(meta.title || 'Report'))}) /Producer (VoltSlot) /Creator (VoltSlot) >>`);
    const parts = [Buffer.from('%PDF-1.4\n', 'latin1')]; const offsets = []; let pos = parts[0].length;
    objs.forEach((o, i) => {
      offsets.push(pos);
      const body = o.stream
        ? Buffer.concat([Buffer.from(`${i + 1} 0 obj\n<< /Length ${o.stream.length} >>\nstream\n`, 'latin1'), o.stream, Buffer.from('\nendstream\nendobj\n', 'latin1')])
        : Buffer.from(`${i + 1} 0 obj\n${o}\nendobj\n`, 'latin1');
      parts.push(body); pos += body.length;
    });
    let xref = `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
    offsets.forEach((o) => { xref += String(o).padStart(10, '0') + ' 00000 n \n'; });
    xref += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R /Info ${info} 0 R >>\nstartxref\n${pos}\n%%EOF\n`;
    parts.push(Buffer.from(xref, 'latin1'));
    return Buffer.concat(parts);
  }
}

module.exports = { Pdf, wrap, width, clean, PAGE_W, PAGE_H };
