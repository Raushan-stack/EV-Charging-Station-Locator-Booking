'use strict';
// Admin reports: complete information about one user (JSON + PDF) and a summary of all users (PDF).
const { query } = require('../db');
const { AppError } = require('../errors');
const { Pdf, wrap, width, PAGE_W, PAGE_H } = require('./pdfWriter');

const INK = '#0C1A24', MUTED = '#51636E', TEAL = '#0A6C74', LINE = '#C9D3D8', PALE = '#EEF3F4', WHITE = '#FFFFFF';
const MARGIN = 50, CONTENT_W = PAGE_W - MARGIN * 2, BOTTOM = PAGE_H - 55;

const money = (n) => 'Rs. ' + Number(n || 0).toFixed(2);
const num = (n, d = 2) => Number(n || 0).toFixed(d);
const dt = (s) => (s ? String(s).slice(0, 16).replace('T', ' ') : '-');

// ------------------------------------------------------------------ data ---------------
async function userList(search) {
  const where = ["u.role = 'USER'"]; const p = [];
  if (search && String(search).trim()) {
    const like = `%${String(search).trim()}%`;
    where.push('(u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)'); p.push(like, like, like);
  }
  return query(
    `SELECT u.user_id, u.name, u.email, u.phone, u.is_active, u.created_at,
            (SELECT COUNT(*) FROM booking b WHERE b.user_id = u.user_id) AS bookings,
            (SELECT COUNT(*) FROM booking b WHERE b.user_id = u.user_id AND b.status = 'COMPLETED') AS completed,
            (SELECT COUNT(*) FROM booking b WHERE b.user_id = u.user_id AND b.status = 'CANCELLED') AS cancelled,
            (SELECT COALESCE(SUM(cs.energy_kwh), 0) FROM charging_session cs JOIN booking b ON b.booking_id = cs.booking_id
              WHERE b.user_id = u.user_id AND cs.status = 'COMPLETED') AS energy_kwh,
            (SELECT COALESCE(SUM(pm.amount), 0) FROM payment pm JOIN booking b ON b.booking_id = pm.booking_id
              WHERE b.user_id = u.user_id AND pm.status = 'PAID') AS paid_amount,
            (SELECT COALESCE(SUM(pm.amount), 0) FROM payment pm JOIN booking b ON b.booking_id = pm.booking_id
              WHERE b.user_id = u.user_id AND pm.status = 'PENDING') AS pending_amount
       FROM users u WHERE ${where.join(' AND ')} ORDER BY u.created_at DESC, u.user_id DESC`, p);
}

async function userReport(userId) {
  const users = await query('SELECT user_id, name, email, phone, role, is_active, created_at FROM users WHERE user_id = ?', [userId]);
  if (!users.length) throw new AppError(404, 'USER_NOT_FOUND', 'User not found');
  const bookings = await query('SELECT * FROM User_Booking_History_View WHERE user_id = ? ORDER BY slot_start DESC, booking_id DESC', [userId]);
  const sum = (arr, f) => arr.reduce((a, r) => a + Number(f(r) || 0), 0);
  const done = bookings.filter((b) => b.session_status === 'COMPLETED');
  const summary = {
    total_bookings: bookings.length,
    completed: bookings.filter((b) => b.booking_status === 'COMPLETED').length,
    cancelled: bookings.filter((b) => b.booking_status === 'CANCELLED').length,
    active: bookings.filter((b) => ['CONFIRMED', 'IN_PROGRESS'].includes(b.booking_status)).length,
    energy_kwh: sum(done, (b) => b.energy_kwh),
    total_billed: sum(bookings.filter((b) => b.payment_status), (b) => b.payment_amount),
    paid_amount: sum(bookings.filter((b) => b.payment_status === 'PAID'), (b) => b.payment_amount),
    pending_amount: sum(bookings.filter((b) => b.payment_status === 'PENDING'), (b) => b.payment_amount),
  };
  return { generated_at: new Date().toISOString().slice(0, 19).replace('T', ' '), user: users[0], summary, bookings };
}

// ------------------------------------------------------------------ PDF helpers --------
class Doc {
  constructor(title, subtitle) {
    this.pdf = new Pdf(); this.title = title; this.subtitle = subtitle; this.y = 0;
    this.newPage();
  }
  newPage() {
    const p = this.pdf; p.addPage();
    p.rect(0, 0, PAGE_W, 62, { fill: TEAL });
    p.text('VoltSlot', MARGIN, 18, { size: 19, font: 'F2', color: WHITE });
    p.text('EV Charging Station Locator & Booking', MARGIN, 42, { size: 8.5, color: '#CFE6E8' });
    p.text(this.title, PAGE_W - MARGIN, 18, { size: 13, font: 'F2', color: WHITE, align: 'right' });
    p.text(this.subtitle, PAGE_W - MARGIN, 38, { size: 8.5, color: '#CFE6E8', align: 'right' });
    this.y = 84;
  }
  need(h) { if (this.y + h > BOTTOM) this.newPage(); }
  heading(text) {
    this.need(40);
    const p = this.pdf;
    p.text(text.toUpperCase(), MARGIN, this.y, { size: 9.5, font: 'F2', color: TEAL });
    p.line(MARGIN, this.y + 15, PAGE_W - MARGIN, this.y + 15, { stroke: TEAL, lw: 1 });
    this.y += 24;
  }
  // two-column key/value block
  keyValues(pairs) {
    const p = this.pdf; const colW = CONTENT_W / 2;
    for (let i = 0; i < pairs.length; i += 2) {
      this.need(30);
      [pairs[i], pairs[i + 1]].forEach((kv, j) => {
        if (!kv) return;
        const x = MARGIN + j * colW;
        p.text(kv[0], x, this.y, { size: 7.5, color: MUTED });
        p.text(kv[1], x, this.y + 11, { size: 10, font: 'F2', maxW: colW - 12 });
      });
      this.y += 30;
    }
  }
  tiles(items, perRow = 4) {
    const p = this.pdf; const gap = 8; const w = (CONTENT_W - gap * (perRow - 1)) / perRow;
    for (let i = 0; i < items.length; i += perRow) {
      this.need(52);
      items.slice(i, i + perRow).forEach(([label, value], j) => {
        const x = MARGIN + j * (w + gap);
        p.rect(x, this.y, w, 44, { fill: PALE, stroke: LINE });
        p.text(label, x + 8, this.y + 7, { size: 7.5, color: MUTED, maxW: w - 12 });
        p.text(value, x + 8, this.y + 21, { size: 12.5, font: 'F2', maxW: w - 12 });
      });
      this.y += 52;
    }
  }
  // columns: [{ title, w, align }], rows: arrays of strings; text wraps inside each cell
  table(columns, rows, { size = 7.6, footerRow } = {}) {
    const p = this.pdf; const pad = 4; const lh = size + 2.6;
    const header = () => {
      this.need(24);
      p.rect(MARGIN, this.y, CONTENT_W, 18, { fill: INK });
      let x = MARGIN;
      columns.forEach((c) => {
        p.text(c.title, c.align === 'right' ? x + c.w - pad : x + pad, this.y + 5, { size: 7.4, font: 'F2', color: WHITE, align: c.align || 'left', maxW: c.w - pad * 2 });
        x += c.w;
      });
      this.y += 18;
    };
    header();
    const drawRow = (cells, { bold = false, fill } = {}) => {
      const wrapped = cells.map((c, i) => wrap(c, columns[i].w - pad * 2, size, bold ? 'F2' : 'F1'));
      const h = Math.max(...wrapped.map((l) => l.length)) * lh + pad * 2 - 1;
      if (this.y + h > BOTTOM) { this.newPage(); header(); }
      if (fill) p.rect(MARGIN, this.y, CONTENT_W, h, { fill });
      let x = MARGIN;
      wrapped.forEach((lines, i) => {
        lines.forEach((ln, k) => {
          const c = columns[i];
          p.text(ln, c.align === 'right' ? x + c.w - pad : x + pad, this.y + pad + k * lh, { size, font: bold ? 'F2' : 'F1', align: c.align || 'left' });
        });
        x += columns[i].w;
      });
      p.line(MARGIN, this.y + h, MARGIN + CONTENT_W, this.y + h);
      this.y += h;
    };
    if (!rows.length) drawRow(['No records'].concat(columns.slice(1).map(() => '')));
    rows.forEach((r, i) => drawRow(r, { fill: i % 2 ? '#F7FAFB' : null }));
    if (footerRow) drawRow(footerRow, { bold: true, fill: PALE });
    this.y += 14;
  }
  finish(meta) {
    // footer with page numbers on every page
    const total = this.pdf.pages.length;
    this.pdf.pages.forEach((_, i) => {
      this.pdf.cur = this.pdf.pages[i];
      this.pdf.line(MARGIN, PAGE_H - 40, PAGE_W - MARGIN, PAGE_H - 40);
      this.pdf.text('Confidential - VoltSlot administrator report', MARGIN, PAGE_H - 33, { size: 7.5, color: MUTED });
      this.pdf.text(`Page ${i + 1} of ${total}`, PAGE_W - MARGIN, PAGE_H - 33, { size: 7.5, color: MUTED, align: 'right' });
    });
    return this.pdf.build(meta);
  }
}

// ------------------------------------------------------------------ PDF: one user ------
function userReportPdf(rep) {
  const u = rep.user, s = rep.summary;
  const d = new Doc('User Account Report', `Generated ${rep.generated_at}`);

  d.heading('Account details');
  d.keyValues([
    ['User ID', '#' + u.user_id], ['Full name', u.name],
    ['Email', u.email], ['Phone', u.phone || '-'],
    ['Account type', u.role === 'ADMIN' ? 'Administrator' : 'EV user'], ['Status', u.is_active ? 'Active' : 'Deactivated'],
    ['Registered on', dt(u.created_at)],
  ]);

  d.heading('Summary');
  d.tiles([
    ['Total bookings', String(s.total_bookings)], ['Completed', String(s.completed)],
    ['Cancelled', String(s.cancelled)], ['Active now', String(s.active)],
    ['Energy charged', num(s.energy_kwh) + ' kWh'], ['Total billed', money(s.total_billed)],
    ['Amount paid', money(s.paid_amount)], ['Payment due', money(s.pending_amount)],
  ]);

  d.heading('Bookings and charging sessions');
  const battery = (b) => {
    if (b.battery_start_pct == null) return '-';
    return `${b.battery_start_pct}% -> ${b.battery_end_pct != null ? b.battery_end_pct + '%' : (b.battery_target_pct != null ? b.battery_target_pct + '% (plan)' : '?')}`;
  };
  d.table(
    [{ title: 'ID', w: 26 }, { title: 'Station / charger', w: 118 }, { title: 'Slot', w: 84 }, { title: 'Status', w: 62 },
      { title: 'Battery', w: 60 }, { title: 'kWh', w: 36, align: 'right' }, { title: 'Amount', w: 52, align: 'right' }, { title: 'Payment', w: 57 }],
    rep.bookings.map((b) => [
      String(b.booking_id), `${b.station_name} (${b.charger_type} #${b.charger_id})`,
      `${dt(b.slot_start)} - ${String(b.slot_end).slice(11, 16)}`, b.booking_status.replace('_', ' '), battery(b),
      b.energy_kwh != null ? num(b.energy_kwh) : '-', b.payment_amount != null ? num(b.payment_amount) : '-',
      b.payment_status ? b.payment_status + (b.payment_method ? ' / ' + b.payment_method : '') : '-',
    ]),
    { footerRow: ['', 'TOTAL', '', '', '', num(s.energy_kwh), num(s.total_billed), ''] });

  const paid = rep.bookings.filter((b) => b.payment_status);
  d.heading('Payment details');
  d.table(
    [{ title: 'Booking', w: 48 }, { title: 'Transaction reference', w: 150 }, { title: 'Amount (Rs.)', w: 70, align: 'right' },
      { title: 'Status', w: 60 }, { title: 'Method', w: 70 }, { title: 'Paid at', w: 97 }],
    paid.map((b) => [`#${b.booking_id}`, b.transaction_ref || '-', num(b.payment_amount), b.payment_status, b.payment_method || '-', dt(b.payment_paid_at)]),
    { footerRow: ['', 'Paid / Due', `${num(s.paid_amount)} / ${num(s.pending_amount)}`, '', '', ''] });

  return d.finish({ title: `User report - ${u.name}` });
}

// ------------------------------------------------------------------ PDF: all users -----
function usersSummaryPdf(users, generatedAt) {
  const d = new Doc('All Users Summary', `Generated ${generatedAt}`);
  const t = users.reduce((a, u) => ({ b: a.b + u.bookings, e: a.e + Number(u.energy_kwh), p: a.p + Number(u.paid_amount), d: a.d + Number(u.pending_amount) }),
    { b: 0, e: 0, p: 0, d: 0 });
  d.heading('Overview');
  d.tiles([['Registered users', String(users.length)], ['Total bookings', String(t.b)], ['Energy charged', num(t.e) + ' kWh'], ['Amount collected', money(t.p)]]);
  d.heading('Users');
  d.table(
    [{ title: 'ID', w: 24 }, { title: 'Name', w: 78 }, { title: 'Email', w: 118 }, { title: 'Phone', w: 58 },
      { title: 'Book.', w: 34, align: 'right' }, { title: 'Done', w: 32, align: 'right' }, { title: 'kWh', w: 40, align: 'right' },
      { title: 'Paid (Rs.)', w: 56, align: 'right' }, { title: 'Due (Rs.)', w: 55, align: 'right' }],
    users.map((u) => [String(u.user_id), u.name, u.email, u.phone || '-', String(u.bookings), String(u.completed), num(u.energy_kwh), num(u.paid_amount), num(u.pending_amount)]),
    { footerRow: ['', 'TOTAL', '', '', String(t.b), '', num(t.e), num(t.p), num(t.d)] });
  return d.finish({ title: 'All users summary' });
}

module.exports = { userList, userReport, userReportPdf, usersSummaryPdf };
