'use strict';
// User portal + admin portal features:
//  10-digit phone | one administrator | separate sites | notifications (station + slot time) |
//  battery plan | payment | "fully charged / slot released" | admin user reports (JSON + PDF)
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');

before(h.start);
after(h.stop);

const newPhone = () => String(7000000000 + Math.floor(Math.random() * 999999999));
async function register(extra = {}) {
  const n = h.uniq();
  const body = { name: `Portal ${n}`, email: `portal${n}@test.local`, phone: newPhone(), password: 'Secret123', ...extra };
  const r = await h.api('POST', '/api/auth/register', { body });
  return { r, body };
}
async function bookNow(user, { startOffset = -5, power = 50, price = 10 } = {}) {   // a slot that is open right now
  const c = await h.makeCharger({ power, price });
  const slot = await h.makeSlot(c.chargerId, startOffset, 60);
  const r = await h.api('POST', '/api/bookings', { token: user.token, body: { slot_id: slot } });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return { slot, bookingId: r.body.data.booking_id, chargerId: c.chargerId };
}

test('P1 phone number must be exactly 10 digits', async () => {
  for (const phone of ['123456789', '12345678901', 'abcdefghij', '98765 4321', '+919876543']) {
    const { r } = await register({ phone });
    assert.equal(r.status, 400, `phone "${phone}" should be rejected`);
  }
  const ok = await register({ phone: '9876543210' });
  assert.equal(ok.r.status, 201, JSON.stringify(ok.r.body));
  // the database refuses a bad phone number even when the API is bypassed
  await assert.rejects(h.db.query("INSERT INTO users (name,email,phone,password_hash) VALUES (?,?,?,?)", [`Raw ${h.uniq()}`, `raw${h.uniq()}@t.local`, '12345', 'x']));
  // profile update uses the same rule
  const upd = await h.api('PUT', '/api/auth/me', { token: ok.r.body.data.token, body: { name: ok.body.name, phone: '12345' } });
  assert.equal(upd.status, 400);
});

test('P2 registration always creates a normal user (role cannot be chosen)', async () => {
  const { r } = await register({ role: 'ADMIN' });
  assert.equal(r.status, 201);
  assert.equal(r.body.data.user.role, 'USER');
  const row = await h.one('SELECT role FROM users WHERE user_id = ?', [r.body.data.user.user_id]);
  assert.equal(row.role, 'USER');
});

test('P3 the database allows exactly ONE administrator', async () => {
  const admins = await h.one("SELECT COUNT(*) AS n FROM users WHERE role = 'ADMIN'");
  assert.equal(admins.n, 1);
  await assert.rejects(h.db.query("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?, 'ADMIN')", [`Second ${h.uniq()}`, `second${h.uniq()}@t.local`, '9111111111', 'x']));
  const u = await h.makeUser();
  await assert.rejects(h.db.query("UPDATE users SET role = 'ADMIN' WHERE user_id = ?", [u.id]));
  // ... and any number of normal users can register
  for (let i = 0; i < 3; i++) assert.equal((await register()).r.status, 201);
});

test('P4 user site and admin site only accept their own accounts', async () => {
  const { r, body } = await register();
  assert.equal(r.status, 201);
  const userOnAdmin = await h.api('POST', '/api/auth/login', { body: { login: body.email, password: body.password, portal: 'admin' } });
  assert.equal(userOnAdmin.status, 403); assert.equal(userOnAdmin.body.error.code, 'NOT_ADMIN');
  const userOnUser = await h.api('POST', '/api/auth/login', { body: { login: body.email, password: body.password, portal: 'user' } });
  assert.equal(userOnUser.status, 200);
  const adminOnUser = await h.api('POST', '/api/auth/login', { body: { login: 'admin@evcharge.test', password: 'Password@123', portal: 'user' } });
  assert.equal(adminOnUser.status, 403); assert.equal(adminOnUser.body.error.code, 'ADMIN_USE_ADMIN_PORTAL');
  const adminOnAdmin = await h.api('POST', '/api/auth/login', { body: { login: 'admin@evcharge.test', password: 'Password@123', portal: 'admin' } });
  assert.equal(adminOnAdmin.status, 200);
  const wrong = await h.api('POST', '/api/auth/login', { body: { login: body.email, password: 'WrongPass1', portal: 'admin' } });
  assert.equal(wrong.status, 401);          // a wrong password never reveals which site the account belongs to
});

test('P5 booking sends a notification with the station name and slot timing', async () => {
  const u = await h.makeUser();
  const c = await h.makeCharger();
  const slot = await h.makeSlot(c.chargerId, 300, 60);
  const b = await h.api('POST', '/api/bookings', { token: u.token, body: { slot_id: slot } });
  assert.equal(b.status, 201);
  const list = await h.api('GET', '/api/notifications', { token: u.token });
  assert.equal(list.status, 200);
  const note = list.body.data.find((n) => n.booking_id === b.body.data.booking_id && n.type === 'BOOKED');
  assert.ok(note, 'a BOOKED notification must exist');
  const info = await h.one(`SELECT st.name AS station, DATE_FORMAT(s.start_time, '%H:%i') AS a, DATE_FORMAT(s.end_time, '%H:%i') AS b
                              FROM charging_slot s JOIN charger c ON c.charger_id = s.charger_id JOIN charging_station st ON st.station_id = c.station_id
                             WHERE s.slot_id = ?`, [slot]);
  assert.ok(note.message.includes(info.station), 'message must contain the station name');
  assert.ok(note.message.includes(`${info.a} - ${info.b}`), 'message must contain the slot timing');
  assert.ok(list.body.meta.unread >= 1);
  assert.equal((await h.api('POST', '/api/notifications/read', { token: u.token, body: {} })).status, 200);
  assert.equal((await h.api('GET', '/api/notifications', { token: u.token })).body.meta.unread, 0);
  // a different user never sees it
  const other = await h.makeUser();
  assert.equal((await h.api('GET', '/api/notifications', { token: other.token })).body.data.length, 0);
});

test('P6 a rolled-back booking leaves no notification', async () => {
  const u = await h.makeUser();
  const c = await h.makeCharger();
  const slot = await h.makeSlot(c.chargerId, 300, 60);
  const r = await h.api('POST', '/api/bookings', { token: u.token, body: { slot_id: slot, simulate_failure: true } });
  assert.ok(r.status >= 400);
  assert.equal((await h.one('SELECT COUNT(*) AS n FROM notification WHERE user_id = ?', [u.id])).n, 0);
});

test('P7 charging complete: slot released for others, bill PENDING, payment makes it PAID', async () => {
  const u = await h.makeUser(); const other = await h.makeUser();
  const { slot, bookingId } = await bookNow(u, { power: 50, price: 10 });
  const st = await h.api('POST', '/api/sessions/start', { token: u.token, body: { booking_id: bookingId } });
  assert.equal(st.status, 201);
  const end = await h.api('POST', `/api/sessions/${st.body.data.session_id}/end`, { token: u.token, body: { energy_kwh: 20 } });
  assert.equal(end.status, 200, JSON.stringify(end.body));

  assert.equal((await h.one('SELECT status FROM booking WHERE booking_id = ?', [bookingId])).status, 'COMPLETED');
  assert.equal((await h.one('SELECT status FROM charging_slot WHERE slot_id = ?', [slot])).status, 'AVAILABLE', 'slot must be empty again');
  const pay = await h.one('SELECT amount, status, method FROM payment WHERE booking_id = ?', [bookingId]);
  assert.equal(pay.amount, 200); assert.equal(pay.status, 'PENDING'); assert.equal(pay.method, null);
  // another driver can take the freed slot right away
  const again = await h.api('POST', '/api/bookings', { token: other.token, body: { slot_id: slot } });
  assert.equal(again.status, 201, 'a released slot must be bookable by another user');

  // paying: only the owner, only once, only a valid method
  assert.equal((await h.api('POST', `/api/trip/bookings/${bookingId}/pay`, { token: other.token, body: { method: 'UPI' } })).status, 404);
  assert.equal((await h.api('POST', `/api/trip/bookings/${bookingId}/pay`, { token: u.token, body: { method: 'BITCOIN' } })).status, 400);
  const ok = await h.api('POST', `/api/trip/bookings/${bookingId}/pay`, { token: u.token, body: { method: 'UPI' } });
  assert.equal(ok.status, 200, JSON.stringify(ok.body));
  const paid = await h.one('SELECT status, method, paid_at FROM payment WHERE booking_id = ?', [bookingId]);
  assert.equal(paid.status, 'PAID'); assert.equal(paid.method, 'UPI'); assert.ok(paid.paid_at);
  const twice = await h.api('POST', `/api/trip/bookings/${bookingId}/pay`, { token: u.token, body: { method: 'UPI' } });
  assert.equal(twice.status, 409); assert.equal(twice.body.error.code, 'ALREADY_PAID');

  const types = (await h.api('GET', '/api/notifications?limit=50', { token: u.token })).body.data.map((n) => n.type);
  for (const t of ['BOOKED', 'CHARGING', 'COMPLETE', 'PAYMENT']) assert.ok(types.includes(t), `missing ${t} notification`);
  const sum = await h.api('GET', '/api/trip/summary', { token: u.token });
  assert.equal(sum.body.data.paid_amount, 200); assert.equal(sum.body.data.due_amount, 0);
});

test('P8 cancelling sends a notification; battery plan is saved and the final level is calculated', async () => {
  const u = await h.makeUser(); const other = await h.makeUser();
  const c = await h.makeCharger();
  const slot = await h.makeSlot(c.chargerId, 600, 60);
  const bk = await h.api('POST', '/api/bookings', { token: u.token, body: { slot_id: slot } });
  const id = bk.body.data.booking_id;
  const good = { battery_start_pct: 20, battery_target_pct: 80, battery_capacity_kwh: 40 };
  assert.equal((await h.api('PUT', `/api/trip/bookings/${id}/battery`, { token: u.token, body: good })).status, 200);
  const row = await h.one('SELECT battery_start_pct s, battery_target_pct t, battery_capacity_kwh c FROM booking WHERE booking_id = ?', [id]);
  assert.deepEqual([row.s, row.t, row.c], [20, 80, 40]);
  assert.equal((await h.api('PUT', `/api/trip/bookings/${id}/battery`, { token: u.token, body: { ...good, battery_target_pct: 10 } })).status, 400);
  assert.equal((await h.api('PUT', `/api/trip/bookings/${id}/battery`, { token: u.token, body: { ...good, battery_capacity_kwh: 0 } })).status, 400);
  assert.equal((await h.api('PUT', `/api/trip/bookings/${id}/battery`, { token: other.token, body: good })).status, 404);
  assert.equal((await h.api('POST', `/api/bookings/${id}/cancel`, { token: u.token })).status, 200);
  const types = (await h.api('GET', '/api/notifications', { token: u.token })).body.data.map((n) => n.type);
  assert.ok(types.includes('CANCELLED'));

  // final battery level = start % + energy / capacity
  const { bookingId } = await bookNow(u);
  await h.api('PUT', `/api/trip/bookings/${bookingId}/battery`, { token: u.token, body: good });
  const st = await h.api('POST', '/api/sessions/start', { token: u.token, body: { booking_id: bookingId } });
  await h.api('POST', `/api/sessions/${st.body.data.session_id}/end`, { token: u.token, body: { energy_kwh: 10 } });
  const s = await h.one('SELECT battery_end_pct AS e FROM charging_session WHERE session_id = ?', [st.body.data.session_id]);
  assert.equal(s.e, 45);       // 20 + 10 / 40 * 100
});

test('P9 admin: every user with complete details, PDF per user, summary PDF; users are refused', async () => {
  const admin = await h.makeUser('ADMIN'); const u = await h.makeUser();
  const { bookingId } = await bookNow(u);
  assert.equal((await h.api('GET', '/api/admin/users', { token: u.token })).status, 403);
  assert.equal((await h.api('GET', `/api/admin/users/${u.id}/report`, { token: u.token })).status, 403);
  assert.equal((await h.raw('GET', `/api/admin/users/${u.id}/report/pdf`, { token: u.token })).status, 403);

  const list = await h.api('GET', '/api/admin/users', { token: admin.token });
  assert.equal(list.status, 200);
  assert.ok(list.body.data.every((x) => x.name && x.email && x.phone), 'users have name, email and phone');
  assert.ok(list.body.data.some((x) => x.user_id === u.id));
  assert.ok(!list.body.data.some((x) => x.email === 'admin@evcharge.test'), 'the administrator is not listed as a user');

  const rep = await h.api('GET', `/api/admin/users/${u.id}/report`, { token: admin.token });
  assert.equal(rep.status, 200);
  assert.equal(rep.body.data.summary.total_bookings, 1);
  assert.equal(rep.body.data.bookings[0].booking_id, bookingId);
  assert.equal((await h.api('GET', '/api/admin/users/99999999/report', { token: admin.token })).status, 404);

  const pdf = await h.raw('GET', `/api/admin/users/${u.id}/report/pdf`, { token: admin.token });
  assert.equal(pdf.status, 200); assert.match(pdf.type, /application\/pdf/); assert.match(pdf.disposition, /attachment/);
  assert.equal(pdf.buffer.subarray(0, 5).toString(), '%PDF-'); assert.ok(pdf.buffer.length > 1500);
  const all = await h.raw('GET', '/api/admin/reports/users-summary/pdf', { token: admin.token });
  assert.equal(all.status, 200); assert.equal(all.buffer.subarray(0, 5).toString(), '%PDF-');

  const fin = await h.api('GET', '/api/admin/finance', { token: admin.token });
  assert.equal(fin.status, 200); assert.ok('paid_total' in fin.body.data && 'pending_total' in fin.body.data);
  assert.equal((await h.api('GET', '/api/admin/payments', { token: admin.token })).status, 200);
});
