# VoltSlot - EV Charging Station Locator & Booking

DBMS project (SDG 7: Affordable & Clean Energy) - Aarya and Raushan.

VoltSlot has **two separate websites** served by one backend:

| Site | Address | For |
|------|---------|-----|
| **User site** | http://localhost:3000 | Drivers: battery planner, map, nearest stations, free slots, booking, charging, payment, notifications. **Unlimited users** can register. |
| **Admin site** | http://localhost:3000/admin/ | The **single administrator**: every user, bookings, sessions, payments, stations, slots, and a **separate PDF report for each user**. |

```
database/   schema (tables, constraints, triggers), stored procedures, views, sample data, SQL tests
backend/    Node.js + Express API (src/), automated tests (tests/)
frontend/   user site (index.html) and admin site (admin/index.html)
docs/       design notes, API reference, viva notes, test report
```

## What is new in this version

1. **Mobile number = exactly 10 digits** (form, API and database CHECK constraint).
2. **One administrator only** - enforced by the database (`UNIQUE` on a generated `admin_flag` column). Registration can never create an admin. Any number of normal users can register.
3. **Different sites for users and admin**, each refusing the other's accounts.
4. **User site:** battery level + target + vehicle size -> energy needed, range, charging time and cost; location (GPS or click on the map); **map with distance line**; nearest stations with free-slot counts; slot grid; booking; charging progress; payment.
5. **Admin site:** dashboard with money and usage totals, every user with complete details, payments, bookings, sessions, stations and slots, and **one PDF per user** (plus an all-users summary PDF).
6. **Fully charged:** when charging ends the app shows "Fully charged / Charging complete" and the **slot is released** (it can be booked by another driver immediately).
7. **Notifications:** booking confirmation with **station name and slot timing**, cancellation, charging started / complete, payment received. They appear as pop-ups and in the bell. Created by database triggers inside the booking transaction.
8. **Easier to use:** guided "How it works" card, next-step hints on every booking, progress steps (Booked > Charging > Complete > Paid), friendly dates, clear messages.

## Run it (Windows, step by step)

Needs **MySQL 8.0.16+** and **Node.js 18+**.

1. **Database:** open `database/00_install_all_in_one.sql` in MySQL Workbench and press the lightning button. (It drops and recreates the database `ev_charging`.)
2. **Settings:** in the `backend` folder copy `.env.example` to `.env` and set `DB_PASSWORD` (your MySQL password) and `JWT_SECRET` (any long random text).
3. **Install and start** (Command Prompt inside the `backend` folder):
   ```
   npm install
   npm run seed:harry
   npm start
   ```
4. Open **http://localhost:3000** (users) or **http://localhost:3000/admin/** (administrator).

`npm run seed:harry` creates the demo driver HARRY. Run it again after every database reinstall.

## Logins

| Who | Site | Login id | Password |
|-----|------|----------|----------|
| Driver (demo) | user site | `HARRY` or harry@example.com | `harry@123` |
| Sample drivers | user site | usera@evcharge.test, userb@evcharge.test, userc@evcharge.test | `Password@123` |
| **Administrator (the only one)** | admin site | admin@evcharge.test | `Password@123` |

The login id can be the email or the name. Names are unique for this reason.

## Demo flow (5 minutes)

1. User site, log in as HARRY. Set battery 30% -> 80%, press **Use my current location** (or click the map). Read the nearest stations.
2. Press **Book a slot** on a station, pick a free slot, confirm. A notification pops up with the **station name and slot time**; the bell shows it too.
3. **My bookings** -> Start charging -> Finish charging (enter kWh). The **Fully charged** screen appears and the slot is free again. Pay the bill.
4. **Double-booking demo** page: one driver gets the slot, the other is rejected.
5. Admin site, log in as admin: Dashboard -> Users -> open HARRY -> **Download PDF report**.

Sample slots cover today and the next days, so you can book the slot of the current hour and charge immediately.

## Tests

* `npm test` (in `backend`) - all automated API + database tests, including `tests/portal.test.js` for the new features.
* `npm run test:aarya` - smoke test against the running server.
* `scripts/run_all_tests.sh root <mysql-password>` - rebuilds a separate test database, runs everything and writes evidence to `docs/evidence/`.

See `docs/COMPLETENESS_AUDIT.md` for what is verified and what is not.
