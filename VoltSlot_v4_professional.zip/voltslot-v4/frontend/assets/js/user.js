/* VoltSlot - USER site.
   Trip planner (battery + location + map) -> nearest stations -> free slots -> book -> charge -> pay. */
'use strict';

const KM_PER_KWH = 6;          // assumed driving efficiency (km per kWh) for the range estimate
const DRIVE_KMH = 30;          // assumed average city speed for the drive-time estimate
const CHARGE_EFF = 0.9;        // charging efficiency
const DEFAULT_POS = { lat: 28.6139, lng: 77.2090 };   // New Delhi, used until the user shares a location

const $app = $('#app');
const state = {
  token: localStorage.getItem('vs_token'),
  user: JSON.parse(localStorage.getItem('vs_user') || 'null'),
  plan: JSON.parse(localStorage.getItem('vs_plan') || 'null') || { battery: 30, target: 80, capacity: 40, lat: null, lng: null },
};
const { raw: rawApi, api } = makeApi(() => state.token, () => logout(true));
/* ---------- notifications (bell) ---------- */
const notif = { rows: [], unread: 0, lastId: null, timer: null };
const NOTE_ICON = { BOOKED: '\u2705', CANCELLED: '\u274C', CHARGING: '\u26A1', COMPLETE: '\uD83D\uDD0B', PAYMENT: '\uD83D\uDCB3' };
// returns how many NEW messages were announced as pop-ups
async function pollNotifications() {
  if (!state.token) return 0;
  let announced = 0;
  try {
    const r = await rawApi('/notifications?limit=30');
    const rows = r.data; notif.rows = rows; notif.unread = r.meta.unread;
    const maxId = rows.length ? rows[0].notification_id : 0;
    if (notif.lastId === null) notif.lastId = maxId;                 // first load: do not pop up old messages
    else if (maxId > notif.lastId) {
      rows.filter((n) => n.notification_id > notif.lastId).reverse().forEach((n) => { toast(`${n.title}: ${n.message}`, 'success', 9000); announced++; });
      notif.lastId = maxId;
    }
    renderBell();
  } catch (e) { /* ignore: the bell simply stays as it is */ }
  return announced;
}
function startNotifications() {
  clearInterval(notif.timer); notif.lastId = null;
  if (!state.token) return;
  pollNotifications(); notif.timer = setInterval(pollNotifications, 15000);
}
function renderBell() {
  const n = $('#bellN'); if (!n) return;
  n.textContent = notif.unread > 9 ? '9+' : notif.unread; n.classList.toggle('hidden', !notif.unread);
  const panel = $('#bellPanel'); if (!panel) return;
  panel.innerHTML = `<div class="spread" style="padding:.7rem .9rem;border-bottom:1px solid var(--line)"><b>Notifications</b>
      <button class="btn sm ghost" id="markAll" ${notif.unread ? '' : 'disabled'}>Mark all read</button></div>
    ${notif.rows.length ? notif.rows.slice(0, 6).map(noteItem).join('') : '<div class="empty small">No notifications yet. We will tell you here when you book a slot.</div>'}
    <a class="bellall" href="#/notifications">View all notifications</a>`;
  const m = $('#markAll'); if (m) m.onclick = async (e) => { e.stopPropagation(); await api('/notifications/read', 'POST', {}); await pollNotifications(); };
}
const noteItem = (n) => `<div class="note ${n.is_read ? '' : 'unread'}"><span class="ico">${NOTE_ICON[n.type] || '\uD83D\uDD14'}</span>
  <div><b>${esc(n.title)}</b><div class="small">${esc(n.message)}</div><div class="tiny muted">${esc(fmtDT(n.created_at))}</div></div></div>`;
document.addEventListener('click', (e) => {
  const panel = $('#bellPanel'); if (!panel) return;
  if (e.target.closest('#bell')) panel.classList.toggle('hidden'); else if (!e.target.closest('#bellPanel')) panel.classList.add('hidden');
});
// "Mon 12 Oct, 10:00 - 11:00"
const when = (a, b) => new Date(a.slice(0, 10) + 'T00:00:00Z').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' }) + ', ' + hhmm(a) + ' - ' + hhmm(b);

const savePlan = () => localStorage.setItem('vs_plan', JSON.stringify(state.plan));

/* ---------- plan maths ---------- */
const needKwh = (p = state.plan) => Math.max(0, (p.capacity * (p.target - p.battery)) / 100);
const rangeKm = (p = state.plan) => (p.battery / 100) * p.capacity * KM_PER_KWH;
const planValid = (p = state.plan) => p.target > p.battery && p.capacity > 0;

function logout(silent) {
  state.token = null; state.user = null;
  localStorage.removeItem('vs_token'); localStorage.removeItem('vs_user'); clearInterval(notif.timer);
  if (!silent) toast('You have been logged out');
  location.hash = '#/login'; route();
}

/* ---------- layout ---------- */
function shell(active, inner) {
  const link = (h, t) => `<a href="${h}" class="${active === h ? 'on' : ''}">${t}</a>`;
  $app.innerHTML = `
    <header class="topbar">
      <a class="brand" href="#/">${boltSvg}<span>VoltSlot</span></a>
      <nav aria-label="Main">${link('#/', 'Plan a charge')}${link('#/bookings', 'My bookings')}${link('#/profile', 'Profile')}${link('#/demo', 'Double-booking demo')}</nav>
      <div class="bellwrap"><button class="linkbtn bell" id="bell" aria-label="Notifications" type="button">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 22a2.5 2.5 0 0 0 2.4-1.8h-4.8A2.5 2.5 0 0 0 12 22zm7-6.2V11a7 7 0 0 0-5.5-6.8V3.5a1.5 1.5 0 0 0-3 0v.7A7 7 0 0 0 5 11v4.8L3.3 17.5V19h17.4v-1.5z"/></svg>
        <span class="bellN hidden" id="bellN"></span></button><div class="bellpanel hidden" id="bellPanel"></div></div>
      <div class="chip-user"><span class="avatar">${esc(state.user.name[0].toUpperCase())}</span><span>${esc(state.user.name)}</span>
        <button class="linkbtn" id="logout">Log out</button></div>
    </header>
    <main class="page">${inner}</main>`;
  $('#logout').onclick = () => logout();
  renderBell();
}

/* ---------- router ---------- */
let navId = 0;                       // lets a slow page ignore its result when the user has already moved on
async function route() {
  navId++;
  const hash = location.hash || '#/';
  if (!state.user) { if (hash !== '#/login') { location.hash = '#/login'; return; } return pageLogin(); }
  if (hash === '#/login') { location.hash = '#/'; return; }
  const pg = $('main.page'); if (pg) pg.innerHTML = '<div class="empty">Loading...</div>';
  try {
    if (hash === '#/notifications') return await pageNotifications();
    if (hash === '#/') return await pageHome();
    if (hash.startsWith('#/station/')) return await pageStation(hash.split('/')[2]);
    if (hash === '#/bookings') return await pageBookings();
    if (hash === '#/profile') return await pageProfile();
    if (hash === '#/demo') return await pageDemo();
    shell('', '<div class="card"><h2>Page not found</h2><a href="#/">Back to home</a></div>');
  } catch (e) { shell('', `<div class="card"><h2>Something went wrong</h2><p>${esc(e.message)}</p></div>`); }
}
window.addEventListener('hashchange', route);

/* =====================================================================
   LOGIN / REGISTER
   ===================================================================== */
function pageLogin() {
  let mode = 'login';
  const draw = () => {
    $app.innerHTML = `
    <div class="auth-wrap">
      <section class="auth-hero">
        <div class="brand" style="font-size:1.4rem">${boltSvg}<span>VoltSlot</span></div>
        <h1>Charge smarter.<br>Never wait for a free charger.</h1>
        <ul>
          <li><span class="dot">1</span><span><b>Tell us your battery level</b><br>We work out how much charge you need and how far you can drive.</span></li>
          <li><span class="dot">2</span><span><b>See the nearest stations on a map</b><br>Distance, free slots, charging time and cost at a glance.</span></li>
          <li><span class="dot">3</span><span><b>Reserve a slot and pay online</b><br>One driver per slot, guaranteed by the database.</span></li>
        </ul>
      </section>
      <section class="auth-form"><div class="card auth-card">
        <h1>${mode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
        <p class="muted">${mode === 'login' ? 'Log in to plan your next charge.' : 'It only takes a minute.'}</p>
        <div class="tabs"><button data-m="login" class="${mode === 'login' ? 'on' : ''}">Log in</button><button data-m="register" class="${mode === 'register' ? 'on' : ''}">Create account</button></div>
        <form id="f" novalidate>
          ${mode === 'register' ? `
            <div class="field"><label for="name">Name <span class="muted">(also your login id)</span></label><input id="name" autocomplete="name" maxlength="100"></div>
            <div class="field"><label for="email">Email</label><input id="email" type="email" autocomplete="email" maxlength="150"></div>
            <div class="field"><label for="phone">Mobile number</label><input id="phone" inputmode="numeric" maxlength="10" autocomplete="tel" placeholder="10 digits">
              <div class="err" id="phoneErr"></div></div>`
          : `<div class="field"><label for="login">Login id or email</label><input id="login" autocomplete="username"></div>`}
          <div class="field"><label for="password">Password${mode === 'register' ? ' <span class="muted">(8+ characters, letters and numbers)</span>' : ''}</label>
            <input id="password" type="password" autocomplete="${mode === 'login' ? 'current-password' : 'new-password'}"></div>
          <button class="btn block" type="submit">${mode === 'login' ? 'Log in' : 'Create account'}</button>
        </form>
        <p class="hint" style="margin-top:1rem">Are you the administrator? <a href="/admin/">Go to the admin site</a></p>
      </div></section>
    </div>`;
    $app.querySelectorAll('[data-m]').forEach((b) => (b.onclick = () => { mode = b.dataset.m; draw(); }));
    const phone = $('#phone');
    if (phone) phone.oninput = () => {
      phone.value = phone.value.replace(/\D/g, '').slice(0, 10);
      $('#phoneErr').textContent = phone.value && phone.value.length !== 10 ? `${phone.value.length}/10 digits` : '';
    };
    $('#f').onsubmit = async (e) => {
      e.preventDefault();
      const v = (id) => ($('#' + id) || {}).value || '';
      try {
        if (mode === 'register' && !PHONE_RE.test(v('phone'))) throw new Error('Mobile number must be exactly 10 digits');
        const data = (await rawApi(mode === 'login' ? '/auth/login' : '/auth/register', 'POST',
          mode === 'login' ? { login: v('login'), password: v('password'), portal: 'user' }
            : { name: v('name'), email: v('email'), phone: v('phone'), password: v('password') }, null)).data;
        state.token = data.token; state.user = data.user;
        localStorage.setItem('vs_token', data.token); localStorage.setItem('vs_user', JSON.stringify(data.user));
        toast('Welcome, ' + data.user.name, 'success');
        location.hash = '#/'; startNotifications(); route();
      } catch (err) { toast(err.message, 'error'); }
    };
  };
  draw();
}

/* =====================================================================
   HOME: battery + location planner, map, nearest stations
   ===================================================================== */
let stationsCache = []; let map = null; let layers = { stations: null, user: null, route: null };
const pos = () => ({ lat: state.plan.lat ?? DEFAULT_POS.lat, lng: state.plan.lng ?? DEFAULT_POS.lng });

async function pageHome() {
  const p = state.plan;
  shell('#/', `
    <div class="pagehead"><div><h1>Plan your charge</h1><p class="muted">Tell us your battery level and where you are. We find the nearest station and tell you how long it will take.</p></div></div>
    ${localStorage.getItem('vs_intro') ? '' : `<div class="card" id="intro" style="background:var(--teal-l);border-color:#9fcfd3">
      <div class="spread"><h2 style="margin:0">How it works</h2><button class="btn sm ghost" id="introOk">Got it</button></div>
      <p class="small" style="margin:.5rem 0 0"><b>1.</b> Set your battery level and share your location. <b>2.</b> Pick the nearest station on the map. <b>3.</b> Choose a free slot and book it &mdash; you will get a notification with the station and time. <b>4.</b> Charge, then pay in <i>My bookings</i>. When charging ends the slot is released for other drivers.</p></div>`}
    <div class="grid cols-2">
      <section class="card" aria-label="Battery planner">
        <h2>Your battery</h2>
        <div class="field"><div class="spread"><label for="bat" style="margin:0">Current battery level</label><span class="slider-val"><span id="batV">${p.battery}</span>%</span></div>
          <input id="bat" type="range" min="1" max="99" value="${p.battery}"></div>
        <div class="field"><div class="spread"><label for="tgt" style="margin:0">Charge up to</label><span class="slider-val"><span id="tgtV">${p.target}</span>%</span></div>
          <input id="tgt" type="range" min="2" max="100" value="${p.target}"></div>
        <div class="battery" aria-hidden="true"><i class="target" id="barT"></i><i id="barB"></i></div>
        <div class="field" style="margin-top:1rem"><label for="cap">Battery size of your vehicle (kWh)</label>
          <input id="cap" type="number" min="5" max="200" step="0.5" value="${p.capacity}">
          <div class="hint">Typical small EV: 25-30 kWh, family EV: 40-60 kWh.</div></div>
        <div class="tiles" style="grid-template-columns:1fr 1fr;margin:0">
          <div class="tile"><div class="k">Energy needed</div><div class="v"><span id="needV">-</span> kWh</div></div>
          <div class="tile"><div class="k">Range now</div><div class="v"><span id="rangeV">-</span> km</div></div>
        </div>
        <div id="planErr" class="err"></div>
        <hr style="border:0;border-top:1px solid var(--line);margin:1rem 0">
        <h2>Your location</h2>
        <p class="small muted" id="locMsg"></p>
        <button class="btn block" id="locBtn" type="button">Use my current location</button>
        <p class="hint">No location? Click anywhere on the map to set where you are.</p>
      </section>
      <section>
        <div id="map" role="application" aria-label="Map of nearby charging stations"></div>
        <div class="legend" style="margin-top:.6rem"><span><i style="border-color:#1f5fbf;background:#1f5fbf"></i>You</span>
          <span><i style="border-color:#17804f;background:#17804f"></i>Free slots</span><span><i style="border-color:#8a99a1;background:#8a99a1"></i>Fully booked</span></div>
      </section>
    </div>
    <div class="pagehead" style="margin-top:.5rem"><h2 style="margin:0">Nearest charging stations</h2>
      <div class="row">
        <div><label for="ft" class="tiny">Connector</label><select id="ft"><option value="ALL">Any</option>${Object.entries(TYPE_LABEL).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
        <div class="check" style="padding-bottom:.55rem;display:flex;gap:.4rem;align-items:center"><input type="checkbox" id="ff" style="width:auto"><label for="ff" style="margin:0;color:var(--ink)">Only with free slots</label></div>
      </div></div>
    <div id="list" class="stations" aria-live="polite"></div>`);

  const refreshPlan = () => {
    const pl = state.plan;
    $('#batV').textContent = pl.battery; $('#tgtV').textContent = pl.target;
    $('#barB').style.width = pl.battery + '%'; $('#barT').style.width = pl.target + '%';
    $('#needV').textContent = num(needKwh(), 1); $('#rangeV').textContent = Math.round(rangeKm());
    $('#planErr').textContent = planValid() ? '' : 'The "charge up to" level must be higher than your current level.';
    savePlan(); renderStations();
  };
  $('#bat').oninput = (e) => { state.plan.battery = Number(e.target.value); if (state.plan.target <= state.plan.battery && state.plan.battery < 100) { state.plan.target = Math.min(100, state.plan.battery + 1); $('#tgt').value = state.plan.target; } refreshPlan(); };
  $('#tgt').oninput = (e) => { state.plan.target = Number(e.target.value); refreshPlan(); };
  $('#cap').oninput = (e) => { const v = Number(e.target.value); if (v > 0) { state.plan.capacity = v; refreshPlan(); } };
  $('#ft').onchange = renderStations; $('#ff').onchange = renderStations;
  $('#locBtn').onclick = () => {
    if (!navigator.geolocation) { $('#locMsg').textContent = 'Your browser does not support location. Click on the map to set your position.'; return; }
    $('#locMsg').textContent = 'Asking for your location...';
    navigator.geolocation.getCurrentPosition(
      (g) => { state.plan.lat = g.coords.latitude; state.plan.lng = g.coords.longitude; savePlan(); loadStations(true); },
      (err) => { $('#locMsg').textContent = err.code === 1 ? 'Location permission was denied. Click on the map to set your position instead.' : 'Your location is not available. Click on the map to set your position instead.'; },
      { timeout: 10000 });
  };
  const ok = $('#introOk'); if (ok) ok.onclick = () => { localStorage.setItem('vs_intro', '1'); $('#intro').remove(); };
  initMap();
  refreshPlan();
  await loadStations(false);
}

function locationText() {
  return state.plan.lat == null ? 'Using a default position (New Delhi). Share your location or click on the map.' : `Your position: ${state.plan.lat.toFixed(4)}, ${state.plan.lng.toFixed(4)}`;
}

async function loadStations(recentre) {
  const { lat, lng } = pos();
  $('#locMsg').textContent = locationText();
  try { stationsCache = await api(`/stations?lat=${lat}&lng=${lng}`); }
  catch (e) { toast(e.message, 'error'); stationsCache = []; }
  renderStations(recentre);
}

function initMap() {
  const box = $('#map');
  if (typeof L === 'undefined') { box.innerHTML = '<div class="empty">The map could not be loaded (no internet connection). The station list below still works.</div>'; map = null; return; }
  const { lat, lng } = pos();
  map = L.map('map').setView([lat, lng], 11);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
  layers = { stations: L.layerGroup().addTo(map), user: L.layerGroup().addTo(map), route: L.layerGroup().addTo(map) };
  map.on('click', (e) => { state.plan.lat = e.latlng.lat; state.plan.lng = e.latlng.lng; savePlan(); selected = null; loadStations(false); });
}

function station_est(s) {
  const need = needKwh(); const range = rangeKm();
  const out = { reachable: s.distance_km <= range * 0.85, driveMin: Math.max(1, Math.round((s.distance_km / DRIVE_KMH) * 60)) };
  if (s.max_power_kw && planValid()) {
    out.chargeMin = Math.max(1, Math.round((need / (s.max_power_kw * CHARGE_EFF)) * 60));
    out.cost = need * s.min_price_per_kwh;
  }
  return out;
}

let selected = null;
function renderStations(recentre) {
  const list = $('#list'); if (!list) return;
  const type = $('#ft').value; const onlyFree = $('#ff').checked;
  const rows = stationsCache.filter((s) => (type === 'ALL' || s.charger_types.includes(type)) && (!onlyFree || s.free_slots > 0));
  list.innerHTML = rows.length ? rows.map((s) => {
    const e = station_est(s);
    const full = s.free_slots === 0;
    return `<article class="st ${selected === s.station_id ? 'sel' : ''}" data-id="${s.station_id}">
      <div>
        <div class="spread"><h3>${esc(s.name)}</h3></div>
        <p class="small muted" style="margin:.1rem 0">${esc(s.address)}</p>
        <div class="meta">
          <span class="badge ${full ? 'bad' : 'ok'}">${full ? 'No free slots' : s.free_slots + ' free slots'}</span>
          ${s.charger_types.map((t) => `<span class="badge">${esc(TYPE_LABEL[t] || t)}</span>`).join('')}
          ${planValid() ? `<span class="badge ${e.reachable ? 'info' : 'warn'}">${e.reachable ? 'Within your battery range' : 'May be out of battery range'}</span>` : ''}
        </div>
        <div class="est"><span>Drive about <b>${e.driveMin} min</b></span>
          ${e.chargeMin ? `<span>Charging <b>${e.chargeMin} min</b> at ${s.max_power_kw} kW</span><span>Est. cost <b>${money(e.cost)}</b></span>` : ''}</div>
        <div class="acts">
          <button class="btn sm ghost" data-show="${s.station_id}">Show route on map</button>
          <a class="btn sm ghost" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&origin=${pos().lat},${pos().lng}&destination=${s.latitude},${s.longitude}">Directions</a>
          <a class="btn sm" href="#/station/${s.station_id}">${full ? 'View slots' : 'Book a slot'}</a>
        </div>
      </div>
      <div class="dist">${num(s.distance_km, 1)} km<div class="tiny muted" style="font-weight:400">straight line</div></div>
    </article>`;
  }).join('') : '<div class="card empty">No stations match these filters.</div>';
  list.querySelectorAll('[data-show]').forEach((b) => (b.onclick = () => { selected = Number(b.dataset.show); renderStations(); drawRoute(); document.getElementById('map').scrollIntoView({ behavior: 'smooth', block: 'center' }); }));
  drawMap(rows, recentre);
}

function drawMap(rows, recentre) {
  if (!map) return;
  layers.stations.clearLayers(); layers.user.clearLayers();
  const { lat, lng } = pos();
  L.circleMarker([lat, lng], { radius: 9, color: '#1f5fbf', fillColor: '#1f5fbf', fillOpacity: .9, weight: 3 }).bindTooltip('You are here').addTo(layers.user);
  L.circle([lat, lng], { radius: rangeKm() * 1000 * 0.85, color: '#1f5fbf', weight: 1, fillOpacity: .04, dashArray: '4 6' }).addTo(layers.user);
  rows.forEach((s) => {
    const ok = s.free_slots > 0;
    const m = L.circleMarker([s.latitude, s.longitude], { radius: 9, color: '#fff', weight: 2, fillColor: ok ? '#17804f' : '#8a99a1', fillOpacity: 1 }).addTo(layers.stations);
    m.bindPopup(`<b>${esc(s.name)}</b><br>${num(s.distance_km, 1)} km away<br>${ok ? s.free_slots + ' free slots' : 'Fully booked'}<br><a href="#/station/${s.station_id}">View slots</a>`);
    m.on('click', () => { selected = s.station_id; renderStations(); drawRoute(); });
  });
  if (recentre) map.setView([lat, lng], 11);
  drawRoute();
}

function drawRoute() {
  if (!map) return; layers.route.clearLayers();
  const s = stationsCache.find((x) => x.station_id === selected); if (!s) return;
  const { lat, lng } = pos();
  const line = L.polyline([[lat, lng], [s.latitude, s.longitude]], { color: '#d98e04', weight: 4, dashArray: '8 8' }).addTo(layers.route);
  line.bindTooltip(`${num(s.distance_km, 1)} km to ${esc(s.name)}`, { permanent: true, direction: 'center', className: 'routetip' });
  map.fitBounds(line.getBounds(), { padding: [50, 50], maxZoom: 14 });
}

/* =====================================================================
   STATION: free slots + booking
   ===================================================================== */
async function pageStation(id, date) {
  const nav = navId;
  const st = await api('/stations/' + id);
  const av = await api(`/stations/${id}/slots` + (date ? `?date=${date}` : ''));
  if (nav !== navId) return;
  const today = av.server_time.slice(0, 10); const day = av.date.slice(0, 10);
  const days = [0, 1, 2, 3].map((n) => addDays(today, n));
  const plan = planValid() ? state.plan : null;

  const chargerBlock = (c) => {
    const slots = av.slots.filter((s) => s.charger_id === c.charger_id);
    const est = plan ? `Needs about <b>${Math.max(1, Math.round((needKwh() / (c.power_kw * CHARGE_EFF)) * 60))} min</b> and <b>${money(needKwh() * c.price_per_kwh)}</b> for your plan` : '';
    return `<div class="charger">
      <div class="charger-head"><h3>${esc(chargerName(c.charger_type, c.charger_id))}</h3>
        <span class="muted small">${c.power_kw} kW &middot; ${money(c.price_per_kwh)} per kWh</span>
        ${c.status === 'ACTIVE' ? '' : `<span class="badge warn">${esc(c.status.toLowerCase())}</span>`}</div>
      ${est ? `<p class="small muted" style="margin:.1rem 0 .5rem">${est}</p>` : ''}
      ${slots.length === 0 ? '<p class="muted small">No slots published for this day.</p>' :
        `<div class="strip">${slots.map((s) => {
          let cls = '', note = 'Free - click to book';
          if (s.my_booking_id) { cls = 'mine'; note = 'Your booking'; }
          else if (s.is_past) { cls = 'past'; note = 'Over'; }
          else if (s.status === 'BOOKED') { cls = 'booked'; note = 'Booked'; }
          else if (s.status === 'BLOCKED' || c.status !== 'ACTIVE') { cls = 'blocked'; note = 'Not available'; }
          return `<button class="slot ${cls}" data-slot="${s.slot_id}" data-c="${esc(chargerName(c.charger_type, c.charger_id))}" data-t="${hhmm(s.start_time)}-${hhmm(s.end_time)}"
                    data-k="${cls || 'free'}" title="${note}" aria-label="${hhmm(s.start_time)} ${note}">${hhmm(s.start_time)}</button>`;
        }).join('')}</div>`}
    </div>`;
  };

  shell('#/', `
    <p><a href="#/">&larr; Back to nearest stations</a></p>
    <div class="card">
      <div class="spread"><div><h1>${esc(st.name)}</h1><p class="muted" style="margin:0">${esc(st.address)}</p></div>
        <a class="btn ghost sm" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&origin=${pos().lat},${pos().lng}&destination=${st.latitude},${st.longitude}">Directions</a></div>
      ${plan ? `<p class="small" style="margin-top:.8rem"><span class="badge info">Your plan</span> ${plan.battery}% &rarr; ${plan.target}% on a ${plan.capacity} kWh battery = <b>${num(needKwh(), 1)} kWh</b></p>`
        : '<p class="small muted" style="margin-top:.8rem">Tip: set your battery level on the <a href="#/">planner</a> to see charging time and cost for each charger.</p>'}
    </div>
    <div class="card">
      <div class="tabs">${days.map((d, i) => `<button data-d="${d}" class="${d === day ? 'on' : ''}">${i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : d} <span class="muted small">${d}</span></button>`).join('')}</div>
      <div class="legend"><span><i style="border-color:var(--teal);background:#fff"></i>Free</span><span><i style="border-color:var(--amber);background:#f6dfa6"></i>Booked</span>
        <span><i style="border-color:var(--green);background:var(--green)"></i>Your booking</span><span><i style="border-color:#9aa8af;background:#cfd8dc"></i>Not available</span></div>
      ${st.chargers.length ? st.chargers.map(chargerBlock).join('') : '<p>This station has no chargers yet.</p>'}
    </div>`);

  $app.querySelectorAll('[data-d]').forEach((b) => (b.onclick = () => pageStation(id, b.dataset.d)));
  $app.querySelectorAll('.slot').forEach((b) => (b.onclick = async () => {
    if (b.dataset.k !== 'free') { toast(b.title); return; }
    const ok = await confirmBox('Confirm booking',
      `<b>${esc(st.name)}</b><br>${esc(b.dataset.c)} &middot; ${esc(day)} &middot; ${esc(b.dataset.t)}` +
      (plan ? `<br><span class="small muted">Battery plan: ${plan.battery}% &rarr; ${plan.target}%</span>` : ''), 'Book this slot');
    if (!ok) return;
    try {
      const r = await api('/bookings', 'POST', { slot_id: Number(b.dataset.slot) });
      if (plan) { try { await api(`/trip/bookings/${r.booking_id}/battery`, 'PUT', { battery_start_pct: plan.battery, battery_target_pct: plan.target, battery_capacity_kwh: plan.capacity }); } catch (e) { /* plan is optional */ } }
      if (!(await pollNotifications())) toast(`Booking #${r.booking_id} confirmed`, 'success');
    } catch (e) { toast(e.message, 'error'); }
    pageStation(id, day);
  }));
}

/* =====================================================================
   MY BOOKINGS: charging progress and payment
   ===================================================================== */
async function pageBookings() {
  const nav = navId;
  const [rows, sum] = await Promise.all([api('/history/bookings?limit=100'), api('/trip/summary')]);
  if (nav !== navId) return;
  const status = (b) => b.booking_status;
  const stepsFor = (b) => {
    const labels = ['Slot booked', 'Charging', 'Charging complete', 'Paid'];
    let done = 0; let now = 1;
    if (status(b) === 'COMPLETED') { done = b.payment_status === 'PAID' ? 4 : 3; now = b.payment_status === 'PAID' ? -1 : 3; }
    else if (status(b) === 'IN_PROGRESS') { done = 1; now = 1; } else { done = 1; now = 1; }
    return `<div class="steps">${labels.map((l, i) => `<div class="${i < done ? 'done' : i === now ? 'now' : ''}">${l}</div>`).join('')}</div>`;
  };
  const batteryBar = (b) => {
    if (b.battery_start_pct == null) return '';
    const end = b.battery_end_pct;
    return `<div style="margin:.4rem 0"><div class="battery"><i class="target" style="width:${b.battery_target_pct || 0}%"></i><i style="width:${end != null ? end : b.battery_start_pct}%"></i></div>
      <div class="tiny muted">Battery ${b.battery_start_pct}% &rarr; ${end != null ? '<b>' + end + '%</b> (charged)' : (b.battery_target_pct || '?') + '% planned'}</div></div>`;
  };
  const hintFor = (b) => {
    if (status(b) === 'CONFIRMED') return '<span class="badge info">Next</span> Go to the station at your slot time, plug in, then press <b>Start charging</b>.';
    if (status(b) === 'IN_PROGRESS') return '<span class="badge warn">Charging</span> Press <b>Finish charging</b> when your vehicle is done. Your slot is released for other drivers right after.';
    if (b.payment_status === 'PENDING') return '<span class="badge warn">Next</span> Your charge is complete. Please pay the bill to close this booking.';
    return '<span class="badge ok">Done</span> Charged and paid. The slot is free for other drivers.';
  };
  const card = (b) => {
    const cancelled = status(b) === 'CANCELLED';
    let actions = '';
    if (status(b) === 'CONFIRMED') actions = `<button class="btn sm" data-start="${b.booking_id}">Start charging</button><button class="btn sm ghost danger" data-cancel="${b.booking_id}">Cancel</button>`;
    else if (status(b) === 'IN_PROGRESS' && b.session_id) actions = `<button class="btn sm" data-end="${b.session_id}" data-bk="${b.booking_id}">Finish charging</button>`;
    else if (status(b) === 'COMPLETED' && b.payment_status === 'PENDING') actions = `<button class="btn sm" data-pay="${b.booking_id}" data-amt="${b.payment_amount}">Pay ${money(b.payment_amount)}</button>`;
    let foot = '';
    if (status(b) === 'COMPLETED') foot = `<span class="small"><b>${num(b.energy_kwh, 2)} kWh</b> charged &middot; <b>${money(b.cost)}</b> &middot; ` +
      (b.payment_status === 'PAID' ? `<span class="badge ok">Paid via ${esc(b.payment_method)}</span> <span class="tiny muted">${esc(b.transaction_ref)}</span>` : '<span class="badge warn">Payment due</span>') + '</span>';
    return `<article class="bk">
      <div class="bk-head"><div><h3>${esc(b.station_name)} <span class="muted small">${esc(chargerName(b.charger_type, b.charger_id))}</span></h3>
        <p class="small muted" style="margin:0">${when(b.slot_start, b.slot_end)} &middot; Booking #${b.booking_id}</p></div>
        <span class="badge ${cancelled ? 'bad' : status(b) === 'COMPLETED' ? 'ok' : 'info'}">${status(b).replace('_', ' ').toLowerCase()}</span></div>
      ${cancelled ? '' : stepsFor(b)}${cancelled ? '' : batteryBar(b)}${cancelled ? '' : `<p class="small" style="margin:.3rem 0 .6rem">${hintFor(b)}</p>`}
      <div class="bk-foot"><div>${foot}</div><div class="actions">${actions}</div></div>
    </article>`;
  };
  const active = rows.filter((b) => ['CONFIRMED', 'IN_PROGRESS'].includes(status(b)) || (status(b) === 'COMPLETED' && b.payment_status === 'PENDING'));
  const past = rows.filter((b) => !active.includes(b));
  shell('#/bookings', `
    <div class="pagehead"><div><h1>My bookings</h1><p class="muted">Track each charge from booking to payment.</p></div></div>
    <div class="tiles">
      <div class="tile"><div class="k">Bookings</div><div class="v">${sum.bookings}</div></div>
      <div class="tile"><div class="k">Energy charged</div><div class="v">${num(sum.energy_kwh, 1)} kWh</div></div>
      <div class="tile good"><div class="k">Total paid</div><div class="v">${money(sum.paid_amount)}</div></div>
      <div class="tile ${sum.due_amount > 0 ? 'warn' : ''}"><div class="k">Payment due</div><div class="v">${money(sum.due_amount)}</div></div>
    </div>
    <h2>Active</h2>${active.length ? active.map(card).join('') : '<div class="card empty">No active bookings. <a href="#/">Find a station</a></div>'}
    <h2 style="margin-top:1.4rem">History</h2>${past.length ? past.map(card).join('') : '<div class="card empty">Nothing here yet.</div>'}`);

  const run = async (fn, okMsg) => { let r; try { r = await fn(); if (!(await pollNotifications())) toast(okMsg, 'success'); } catch (e) { toast(e.message, 'error'); } return r; };
  $app.querySelectorAll('[data-cancel]').forEach((b) => (b.onclick = async () => {
    if (await confirmBox('Cancel booking', 'The slot will be released for other drivers.', 'Cancel booking', true)) { await run(() => api(`/bookings/${b.dataset.cancel}/cancel`, 'POST'), 'Booking cancelled, slot released'); pageBookings(); }
  }));
  $app.querySelectorAll('[data-start]').forEach((b) => (b.onclick = async () => { await run(() => api('/sessions/start', 'POST', { booking_id: Number(b.dataset.start) }), 'Charging started'); pageBookings(); }));
  $app.querySelectorAll('[data-end]').forEach((b) => (b.onclick = async () => {
    const bk = rows.find((r) => r.booking_id === Number(b.dataset.bk));
    const planned = bk.battery_start_pct != null ? (bk.battery_capacity_kwh * (bk.battery_target_pct - bk.battery_start_pct)) / 100 : null;
    const kwh = await modal(`<h2>Finish charging</h2><p>Enter the energy delivered, as shown on the charger.</p>
      <label for="kwh">Energy (kWh)</label><input id="kwh" data-value type="number" min="0.1" step="0.1" value="${planned ? planned.toFixed(1) : ''}" placeholder="e.g. 12.5">
      <div class="actions"><button class="btn ghost" data-cancel>Back</button><button class="btn" data-ok>Finish charging</button></div>`);
    if (kwh === false) return;
    if (!kwh || Number(kwh) <= 0) { toast('Please enter the energy in kWh', 'error'); return; }
    const r = await run(() => api(`/sessions/${b.dataset.end}/end`, 'POST', { energy_kwh: Number(kwh) }), 'Charging complete');
    if (r) await completeDialog(r, bk);
    pageBookings();
  }));
  $app.querySelectorAll('[data-pay]').forEach((b) => (b.onclick = async () => { await payDialog(Number(b.dataset.pay), Number(b.dataset.amt), '<h2 style="margin-top:0">Pay your bill</h2>'); pageBookings(); }));
}

// "Fully charged" screen: shown right after charging ends. The database has already freed the slot.
async function completeDialog(res, bk) {
  let endPct = null;
  if (bk.battery_start_pct != null && bk.battery_capacity_kwh) endPct = Math.min(100, Math.round(bk.battery_start_pct + (res.energy_kwh * 100) / bk.battery_capacity_kwh));
  const full = endPct != null && endPct >= 99;
  const head = `<div style="text-align:center;margin-bottom:.9rem">
      <div style="font-size:2.6rem;line-height:1">${full ? '\uD83D\uDD0B' : '\u26A1'}</div>
      <h2 style="margin:.3rem 0">${full ? 'Fully charged!' : 'Charging complete'}</h2>
      ${endPct != null ? `<div class="battery" style="margin:.7rem 0 .3rem"><i style="width:${endPct}%"></i></div><div class="small">Battery is now about <b>${endPct}%</b></div>` : ''}
      <p class="small" style="margin:.5rem 0 0"><b>${num(res.energy_kwh, 2)} kWh</b> delivered &middot; <span class="badge ok">Your slot is now free for other drivers</span></p></div>`;
  return payDialog(bk.booking_id, res.cost, head);
}

async function payDialog(bookingId, amount, head = '') {
  const m = await modal(`${head}<p>Amount to pay: <b style="font-size:1.3rem">${money(amount)}</b></p>
    <label for="pm">Payment method</label>
    <select id="pm" data-value><option value="UPI">UPI</option><option value="CARD">Debit / credit card</option><option value="NETBANKING">Net banking</option><option value="CASH">Cash at the station</option></select>
    <p class="hint">Payments here are simulated for the project demo.</p>
    <div class="actions"><button class="btn ghost" data-cancel>Pay later</button><button class="btn" data-ok>Pay ${money(amount)}</button></div>`);
  if (!m) { toast('You can pay later from My bookings'); return; }
  try { await api(`/trip/bookings/${bookingId}/pay`, 'POST', { method: m }); if (!(await pollNotifications())) toast('Payment successful. Thank you!', 'success'); }
  catch (e) { toast(e.message, 'error'); }
}

/* =====================================================================
   NOTIFICATIONS PAGE
   ===================================================================== */
async function pageNotifications() {
  const r = await rawApi('/notifications?limit=100');
  shell('', `<div class="pagehead"><div><h1>Notifications</h1><p class="muted">Booking confirmations, charging updates and payment receipts.</p></div>
      <button class="btn ghost" id="readAll" ${r.meta.unread ? '' : 'disabled'}>Mark all as read</button></div>
    <div class="card" style="padding:0">${r.data.length ? r.data.map(noteItem).join('') : '<div class="empty">Nothing yet. When you book a slot, the station name and slot time appear here.</div>'}</div>`);
  $('#readAll').onclick = async () => { await api('/notifications/read', 'POST', {}); await pollNotifications(); pageNotifications(); };
  notif.rows = r.data; notif.unread = r.meta.unread; renderBell();
}

/* =====================================================================
   PROFILE
   ===================================================================== */
async function pageProfile() {
  const me = await api('/auth/me');
  shell('#/profile', `<div class="pagehead"><h1>My profile</h1></div>
    <form class="card" id="pf" style="max-width:480px" novalidate>
      <div class="field"><label>Email</label><input value="${esc(me.email)}" disabled></div>
      <div class="field"><label for="n">Name (login id)</label><input id="n" value="${esc(me.name)}" maxlength="100"></div>
      <div class="field"><label for="p">Mobile number</label><input id="p" value="${esc(me.phone)}" inputmode="numeric" maxlength="10"><div class="err" id="pe"></div></div>
      <button class="btn">Save changes</button></form>`);
  $('#p').oninput = (e) => { e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10); };
  $('#pf').onsubmit = async (e) => {
    e.preventDefault();
    try {
      if (!PHONE_RE.test($('#p').value)) throw new Error('Mobile number must be exactly 10 digits');
      const r = await api('/auth/me', 'PUT', { name: $('#n').value, phone: $('#p').value });
      state.user.name = r.name; localStorage.setItem('vs_user', JSON.stringify(state.user)); toast('Profile updated', 'success'); pageProfile();
    } catch (err) { toast(err.message, 'error'); }
  };
}

/* =====================================================================
   FR-07: double-booking demonstration
   ===================================================================== */
async function pageDemo() {
  const slots = await api('/availability/slots?limit=40');
  shell('#/demo', `<div class="pagehead"><div><h1>Double-booking demonstration</h1>
    <p class="muted">You and a second driver request <b>the same slot at the same moment</b>. The database lets exactly one booking through.</p></div></div>
    <div class="card">
      <div class="field"><label for="ds">Choose a free slot</label>
        <select id="ds">${slots.map((s) => `<option value="${s.slot_id}">${esc(s.station_name)} - ${esc(chargerName(s.charger_type, s.charger_id))} - ${fmtDT(s.start_time)}</option>`).join('')}</select></div>
      <div class="row"><div class="grow"><label for="u2">Second driver (login id)</label><input id="u2" value="userb@evcharge.test"></div>
        <div class="grow"><label for="p2">Second driver password</label><input id="p2" type="password" value="Password@123"></div>
        <button class="btn" id="go" ${slots.length ? '' : 'disabled'}>Run the race</button></div>
      <p class="hint">The second driver is one of the sample users created with the database.</p>
    </div>
    <div id="out"></div>
    <div class="card"><h2>What is happening</h2>
      <p class="small">Both requests call the booking procedure <code>sp_book_slot</code>. It runs as one transaction and locks the slot row. The first request to get the lock books the slot and commits; the second finds the slot already booked and is rolled back with <code>SLOT_UNAVAILABLE</code>. Even if the code had a bug, the <code>UNIQUE(active_slot_id)</code> constraint would still stop a duplicate.</p>
      <p class="small muted">To repeat the demo with the same slot, cancel the winning booking from My bookings.</p></div>`);
  $('#go').onclick = async (e) => {
    e.target.disabled = true;
    try {
      const slotId = Number($('#ds').value);
      const second = (await rawApi('/auth/login', 'POST', { login: $('#u2').value, password: $('#p2').value }, null)).data;
      if (second.user.user_id === state.user.user_id) throw new Error('Choose a second driver who is not you');
      const attempt = async (token, who) => {
        const t0 = performance.now();
        try { const r = await rawApi('/bookings', 'POST', { slot_id: slotId }, token); return { who, ok: true, message: 'Booking confirmed (#' + r.data.booking_id + ')', ms: Math.round(performance.now() - t0) }; }
        catch (err) { return { who, ok: false, message: err.message, code: err.code, ms: Math.round(performance.now() - t0) }; }
      };
      const results = await Promise.all([attempt(state.token, state.user.name), attempt(second.token, second.user.name)]);
      $('#out').innerHTML = `<div class="race">${results.map((x) => `<div class="result ${x.ok ? 'win' : 'lose'}"><b class="big">${x.ok ? 'Booked' : 'Rejected'}</b>
          <p><b>${esc(x.who)}</b></p><p class="small">${esc(x.message)}${x.code ? ' (' + esc(x.code) + ')' : ''}</p><p class="tiny muted">answered after ${x.ms} ms</p></div>`).join('')}</div>
        <div class="card" style="margin-top:1rem"><b>Bookings that succeeded for this slot: ${results.filter((r) => r.ok).length} of 2</b></div>`;
    } catch (err) { toast(err.message, 'error'); }
    e.target.disabled = false;
  };
}

if (state.user) startNotifications();
route();
