/* Helpers shared by the user site and the admin site */
'use strict';
const $ = (sel, root = document) => root.querySelector(sel);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => (n == null ? '-' : '\u20B9' + Number(n).toFixed(2));
const num = (n, d = 1) => (n == null ? '-' : Number(n).toFixed(d));
const fmtDT = (s) => (s ? s.slice(0, 16).replace('T', ' ') : '-');
const hhmm = (s) => s.slice(11, 16);
const addDays = (ymd, n) => { const d = new Date(ymd + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const TYPE_LABEL = { CCS2: 'DC CCS2', CHAdeMO: 'DC CHAdeMO', Type2: 'AC Type 2', GBT: 'GB/T', AC001: 'AC001' };
const chargerName = (type, id) => `${TYPE_LABEL[type] || type} #${id}`;
const PHONE_RE = /^[0-9]{10}$/;

function toast(msg, kind = '', ms = 4800) {
  const el = document.createElement('div');
  el.className = 'toast ' + kind; el.textContent = msg;
  $('#toast').appendChild(el);
  setTimeout(() => el.remove(), ms);
}

// The API answers { success, data } or { success:false, error:{code,message} }
function makeApi(getToken, onUnauthorized) {
  async function raw(path, method = 'GET', body, token = getToken()) {
    let res;
    try {
      res = await fetch('/api' + path, {
        method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
        body: body ? JSON.stringify(body) : undefined });
    } catch (e) { const err = new Error('Cannot reach the server. Is the backend running?'); err.code = 'NETWORK'; throw err; }
    let json = {}; try { json = await res.json(); } catch (e) { /* not JSON */ }
    if (!res.ok || json.success === false) {
      const err = new Error((json.error && json.error.message) || 'Request failed (HTTP ' + res.status + ')');
      err.status = res.status; err.code = json.error && json.error.code; throw err;
    }
    return json;
  }
  async function api(path, method, body) {
    try { return (await raw(path, method, body)).data; }
    catch (e) { if (e.status === 401 && getToken() && e.code !== 'INVALID_CREDENTIALS') onUnauthorized(); throw e; }
  }
  // download a file (PDF) with the login token, then save it
  async function download(path, filename) {
    const res = await fetch('/api' + path, { headers: { Authorization: 'Bearer ' + getToken() } });
    if (!res.ok) { let m = 'Download failed'; try { m = (await res.json()).error.message; } catch (e) { /* ignore */ } throw new Error(m); }
    const blob = await res.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }
  return { raw, api, download };
}

function modal(html) {
  const $m = $('#modal');
  return new Promise((resolve) => {
    $m.innerHTML = `<div class="box" role="dialog" aria-modal="true">${html}</div>`; $m.hidden = false;
    const close = (v) => { $m.hidden = true; $m.innerHTML = ''; resolve(v); };
    const read = () => { const i = $m.querySelector('[data-value]'); return i ? i.value : true; };
    $m.querySelector('[data-ok]').onclick = () => close(read());
    $m.querySelector('[data-cancel]').onclick = () => close(false);
    const inp = $m.querySelector('input[data-value]');
    if (inp) { inp.focus(); inp.onkeydown = (e) => { if (e.key === 'Enter') close(read()); }; }
  });
}
const confirmBox = (title, text, okText = 'Confirm', danger = false) =>
  modal(`<h2>${esc(title)}</h2><p>${text}</p><div class="actions"><button class="btn ghost" data-cancel>Back</button><button class="btn ${danger ? 'danger' : ''}" data-ok>${esc(okText)}</button></div>`);

// small inline table builder: cols = [[title, key|fn, 'r'?]]
function table(cols, rows, empty = 'No records') {
  const head = cols.map((c) => `<th class="${c[2] || ''}">${c[0]}</th>`).join('');
  const body = rows.map((r) => `<tr>${cols.map((c) => `<td class="${c[2] || ''}">${typeof c[1] === 'function' ? c[1](r) : esc(r[c[1]])}</td>`).join('')}</tr>`).join('')
    || `<tr><td colspan="${cols.length}" class="empty">${esc(empty)}</td></tr>`;
  return `<div class="tablewrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}
const boltSvg = '<svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2 4 14h6l-1 8 9-12h-6z" fill="currentColor"/></svg>';
