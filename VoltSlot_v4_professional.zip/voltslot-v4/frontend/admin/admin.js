/* VoltSlot - ADMIN site (single administrator account).
   Dashboard, every user with complete details, payments, bookings, sessions, stations, slots, PDF reports. */
'use strict';

const state = { token: localStorage.getItem('vs_admin_token'), user: JSON.parse(localStorage.getItem('vs_admin_user') || 'null') };
const { raw: rawApi, api, download } = makeApi(() => state.token, () => logout(true));
const $app = $('#app');

function logout(silent) {
  state.token = null; state.user = null;
  localStorage.removeItem('vs_admin_token'); localStorage.removeItem('vs_admin_user');
  if (!silent) toast('Logged out');
  location.hash = '#/login'; route();
}

/* ---------- layout ---------- */
function shell(active, inner) {
  const l = (h, t) => `<a href="${h}" class="${active === h ? 'on' : ''}">${t}</a>`;
  $app.innerHTML = `<div class="admin">
    <aside class="side">
      <a class="brand" href="#/">${boltSvg}<span>VoltSlot</span></a>
      ${l('#/', 'Dashboard')}${l('#/users', 'Users')}${l('#/payments', 'Payments')}${l('#/bookings', 'Bookings')}${l('#/sessions', 'Charging sessions')}
      <div class="sep"></div>${l('#/stations', 'Stations & chargers')}${l('#/slots', 'Slots')}
      <div class="who"><span class="rolechip">ADMIN</span><div style="margin:.4rem 0">${esc(state.user.name)}</div><button class="linkbtn" id="logout" style="padding:0">Log out</button></div>
    </aside>
    <main class="adminmain">${inner}</main></div>`;
  $('#logout').onclick = () => logout();
}
const loading = () => { const m = $('main.adminmain'); if (m) m.innerHTML = '<div class="empty">Loading...</div>'; };

async function route() {
  const hash = location.hash || '#/';
  if (!state.user) { if (hash !== '#/login') { location.hash = '#/login'; return; } return pageLogin(); }
  if (hash === '#/login') { location.hash = '#/'; return; }
  loading();
  try {
    if (hash === '#/') return await pageDashboard();
    if (hash === '#/users') return await pageUsers();
    if (hash.startsWith('#/user/')) return await pageUser(hash.split('/')[2]);
    if (hash === '#/payments') return await pagePayments();
    if (hash === '#/bookings') return await pageBookings();
    if (hash === '#/sessions') return await pageSessions();
    if (hash === '#/stations') return await pageStations();
    if (hash === '#/slots') return await pageSlots();
    shell('', '<div class="card">Page not found. <a href="#/">Dashboard</a></div>');
  } catch (e) { shell('', `<div class="card"><h2>Something went wrong</h2><p>${esc(e.message)}</p></div>`); }
}
window.addEventListener('hashchange', route);

/* ---------- login (administrator only) ---------- */
function pageLogin() {
  $app.innerHTML = `<div class="auth-wrap">
    <section class="auth-hero"><div class="brand" style="font-size:1.4rem">${boltSvg}<span>VoltSlot</span></div>
      <h1>Administrator console</h1>
      <ul><li><span class="dot">&#10003;</span><span><b>Every user, every booking</b><br>Complete records with amounts, energy and payment status.</span></li>
          <li><span class="dot">&#10003;</span><span><b>PDF report per user</b><br>Download a separate PDF with the full details of each user.</span></li>
          <li><span class="dot">&#10003;</span><span><b>One administrator account</b><br>Enforced by the database.</span></li></ul></section>
    <section class="auth-form"><div class="card auth-card">
      <h1>Admin log in</h1><p class="muted">This site is for the administrator only.</p>
      <form id="f" novalidate>
        <div class="field"><label for="login">Admin login id or email</label><input id="login" autocomplete="username"></div>
        <div class="field"><label for="password">Password</label><input id="password" type="password" autocomplete="current-password"></div>
        <button class="btn block" type="submit">Log in</button></form>
      <p class="hint" style="margin-top:1rem">Looking for the charging app? <a href="/">Go to the user site</a></p></div></section></div>`;
  $('#f').onsubmit = async (e) => {
    e.preventDefault();
    try {
      const d = (await rawApi('/auth/login', 'POST', { login: $('#login').value, password: $('#password').value, portal: 'admin' }, null)).data;
      state.token = d.token; state.user = d.user;
      localStorage.setItem('vs_admin_token', d.token); localStorage.setItem('vs_admin_user', JSON.stringify(d.user));
      location.hash = '#/'; route();
    } catch (err) { toast(err.message, 'error'); }
  };
}

const tile = (k, v, cls = '') => `<div class="tile ${cls}"><div class="k">${k}</div><div class="v">${v}</div></div>`;
const statusBadge = (s) => `<span class="badge ${['COMPLETED', 'PAID', 'ACTIVE'].includes(s) ? 'ok' : ['CANCELLED', 'FAILED'].includes(s) ? 'bad' : ['PENDING', 'IN_PROGRESS'].includes(s) ? 'warn' : 'info'}">${esc(String(s || '-').replace('_', ' ').toLowerCase())}</span>`;
const pdfBtn = (path, name, label) => `<button class="btn sm" data-pdf="${path}" data-name="${name}">${label}</button>`;
function bindPdf() {
  $app.querySelectorAll('[data-pdf]').forEach((b) => (b.onclick = async () => {
    b.disabled = true; try { await download(b.dataset.pdf, b.dataset.name); toast('PDF downloaded', 'success'); } catch (e) { toast(e.message, 'error'); } b.disabled = false;
  }));
}

/* =====================================================================
   DASHBOARD
   ===================================================================== */
async function pageDashboard() {
  const [d, f] = await Promise.all([api('/admin/dashboard'), api('/admin/finance')]);
  const active = (d.bookings.CONFIRMED || 0) + (d.bookings.IN_PROGRESS || 0);
  shell('#/', `<div class="pagehead"><div><h1>Dashboard</h1><p class="muted">Everything saved by the system, at a glance.</p></div>
      ${pdfBtn('/admin/reports/users-summary/pdf', 'VoltSlot_all_users_summary.pdf', 'Download all-users summary (PDF)')}</div>
    <div class="tiles">
      ${tile('Registered users', f.users, 'accent')}${tile('Stations', d.stations.total)}${tile('Chargers', d.chargers.total)}
      ${tile('Active bookings', active)}${tile('Live charging sessions', d.sessions.active || 0)}${tile('Energy delivered', num(f.energy_kwh, 1) + ' kWh')}
      ${tile('Money collected', money(f.paid_total), 'good')}${tile('Payments due', money(f.pending_total), f.pending_total > 0 ? 'warn' : '')}
    </div>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(340px,1fr))">
      <div class="card"><h2>Collected by payment method</h2>${table([['Method', 'method'], ['Payments', 'payments', 'r'], ['Amount', (r) => money(r.amount), 'r']], f.by_method, 'No payments yet')}</div>
      <div class="card"><h2>Station utilisation</h2>${table([['Station', 'station_name'], ['Bookings', 'total_bookings', 'r'], ['Completed', 'completed_bookings', 'r'], ['kWh', (r) => num(r.total_energy_kwh, 1), 'r'], ['Revenue', (r) => money(r.total_revenue), 'r']], d.utilization)}</div>
    </div>
    <p class="hint">Only one administrator account exists. Users can register without any limit.</p>`);
  bindPdf();
}

/* =====================================================================
   USERS (list + complete detail + PDF each)
   ===================================================================== */
async function pageUsers() {
  let q = '';
  const draw = async () => {
    const rows = await api('/admin/users' + (q ? '?q=' + encodeURIComponent(q) : ''));
    $('#ulist').innerHTML = table([
      ['ID', 'user_id'], ['Name', (r) => `<a href="#/user/${r.user_id}"><b>${esc(r.name)}</b></a>`], ['Email', 'email'], ['Mobile', 'phone'],
      ['Bookings', 'bookings', 'r'], ['Done', 'completed', 'r'], ['kWh', (r) => num(r.energy_kwh, 1), 'r'], ['Paid', (r) => money(r.paid_amount), 'r'], ['Due', (r) => money(r.pending_amount), 'r'],
      ['Joined', (r) => esc(String(r.created_at).slice(0, 10))],
      ['', (r) => `<a class="btn sm ghost" href="#/user/${r.user_id}">Details</a> ` + pdfBtn(`/admin/users/${r.user_id}/report/pdf`, `VoltSlot_user_${r.user_id}.pdf`, 'PDF')],
    ], rows, 'No users found');
    bindPdf();
  };
  shell('#/users', `<div class="pagehead"><div><h1>Users</h1><p class="muted">Every registered user with complete details. Download a separate PDF for each one.</p></div>
      ${pdfBtn('/admin/reports/users-summary/pdf', 'VoltSlot_all_users_summary.pdf', 'All users summary (PDF)')}</div>
    <div class="card"><div class="row" style="margin-bottom:.8rem"><div class="grow"><label for="q">Search by name, email or mobile</label><input id="q" placeholder="Type to search"></div></div><div id="ulist"></div></div>`);
  let t; $('#q').oninput = (e) => { clearTimeout(t); t = setTimeout(() => { q = e.target.value.trim(); draw(); }, 250); };
  await draw();
}

async function pageUser(id) {
  const rep = await api(`/admin/users/${id}/report`);
  const u = rep.user, s = rep.summary;
  shell('#/users', `<p><a href="#/users">&larr; All users</a></p>
    <div class="pagehead"><div><h1>${esc(u.name)}</h1><p class="muted">User #${u.user_id} &middot; registered ${esc(String(u.created_at).slice(0, 10))}</p></div>
      ${pdfBtn(`/admin/users/${u.user_id}/report/pdf`, `VoltSlot_user_${u.user_id}.pdf`, 'Download this user\'s PDF report')}</div>
    <div class="card"><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
      <div><div class="tiny muted">Email</div><b>${esc(u.email)}</b></div><div><div class="tiny muted">Mobile</div><b>${esc(u.phone || '-')}</b></div>
      <div><div class="tiny muted">Account</div><b>${u.role === 'ADMIN' ? 'Administrator' : 'EV user'}</b></div><div><div class="tiny muted">Status</div>${statusBadge(u.is_active ? 'ACTIVE' : 'INACTIVE')}</div></div></div>
    <div class="tiles">${tile('Bookings', s.total_bookings)}${tile('Completed', s.completed)}${tile('Cancelled', s.cancelled)}${tile('Active now', s.active)}
      ${tile('Energy charged', num(s.energy_kwh, 1) + ' kWh')}${tile('Total billed', money(s.total_billed))}${tile('Amount paid', money(s.paid_amount), 'good')}${tile('Payment due', money(s.pending_amount), s.pending_amount > 0 ? 'warn' : '')}</div>
    <div class="card"><h2>Bookings, charging and payments</h2>${table([
      ['#', 'booking_id'], ['Station / charger', (r) => `${esc(r.station_name)}<div class="tiny muted">${esc(TYPE_LABEL[r.charger_type] || r.charger_type)} #${r.charger_id}</div>`],
      ['Slot', (r) => `${esc(fmtDT(r.slot_start))} - ${esc(hhmm(r.slot_end))}`], ['Status', (r) => statusBadge(r.booking_status)],
      ['Battery', (r) => r.battery_start_pct == null ? '-' : `${r.battery_start_pct}% &rarr; ${r.battery_end_pct != null ? r.battery_end_pct + '%' : (r.battery_target_pct || '?') + '% (plan)'}`],
      ['kWh', (r) => r.energy_kwh != null ? num(r.energy_kwh, 2) : '-', 'r'], ['Amount', (r) => r.payment_amount != null ? money(r.payment_amount) : '-', 'r'],
      ['Payment', (r) => r.payment_status ? statusBadge(r.payment_status) + `<div class="tiny muted">${esc(r.payment_method || '')} ${esc(r.transaction_ref || '')}</div>` : '-'],
    ], rep.bookings, 'This user has no bookings yet')}</div>`);
  bindPdf();
}

/* =====================================================================
   PAYMENTS, BOOKINGS, SESSIONS
   ===================================================================== */
async function pagePayments() {
  const draw = async (status) => {
    const rows = await api('/admin/payments?limit=100' + (status ? '&status=' + status : ''));
    $('#plist').innerHTML = table([['Booking', 'booking_id'], ['User', (r) => `<a href="#/user/${r.user_id}">${esc(r.user_name)}</a>`], ['Station', 'station_name'],
      ['Amount', (r) => money(r.amount), 'r'], ['kWh', (r) => r.energy_kwh != null ? num(r.energy_kwh, 2) : '-', 'r'], ['Status', (r) => statusBadge(r.status)],
      ['Method', (r) => esc(r.method || '-')], ['Reference', 'transaction_ref'], ['Paid at', (r) => esc(fmtDT(r.paid_at))]], rows, 'No payments');
  };
  shell('#/payments', `<div class="pagehead"><div><h1>Payments</h1><p class="muted">All amounts billed and collected.</p></div>
    <div><label for="ps" class="tiny">Show</label><select id="ps"><option value="">All</option><option value="PAID">Paid</option><option value="PENDING">Due</option></select></div></div>
    <div class="card" id="plist"></div>`);
  $('#ps').onchange = (e) => draw(e.target.value);
  await draw('');
}

async function pageBookings() {
  const rows = await api('/admin/bookings?limit=100');
  shell('#/bookings', `<div class="pagehead"><div><h1>Bookings</h1><p class="muted">Latest 100 bookings.</p></div></div><div class="card">${table([
    ['#', 'booking_id'], ['User', (r) => `<a href="#/user/${r.user_id}">${esc(r.user_name)}</a>`], ['Station', 'station_name'], ['Slot', (r) => `${esc(fmtDT(r.slot_start))} - ${esc(hhmm(r.slot_end))}`],
    ['Status', (r) => statusBadge(r.booking_status)], ['Session', (r) => r.session_status ? statusBadge(r.session_status) : '-'], ['Payment', (r) => r.payment_status ? statusBadge(r.payment_status) : '-'],
    ['Booked at', (r) => esc(fmtDT(r.booked_at))]], rows)}</div>`);
}

async function pageSessions() {
  const rows = await api('/admin/sessions?limit=100');
  shell('#/sessions', `<div class="pagehead"><div><h1>Charging sessions</h1><p class="muted">Start, end, energy and cost of every charge.</p></div></div><div class="card">${table([
    ['#', 'session_id'], ['User', (r) => `<a href="#/user/${r.user_id}">${esc(r.user_name)}</a>`], ['Station', 'station_name'], ['Start', (r) => esc(fmtDT(r.start_time))], ['End', (r) => esc(fmtDT(r.end_time))],
    ['Minutes', (r) => r.duration_minutes ?? '-', 'r'], ['kWh', (r) => r.energy_kwh != null ? num(r.energy_kwh, 2) : '-', 'r'], ['Cost', (r) => money(r.cost), 'r'], ['Status', (r) => statusBadge(r.session_status)],
    ['Payment', (r) => r.payment_status ? statusBadge(r.payment_status) : '-']], rows)}</div>`);
}

/* =====================================================================
   STATIONS + SLOTS
   ===================================================================== */
async function pageStations() {
  const [sts, chs] = await Promise.all([api('/admin/stations'), api('/admin/chargers')]);
  shell('#/stations', `<div class="pagehead"><div><h1>Stations & chargers</h1></div></div>
    <div class="card"><h2>Add a station</h2><form class="row" id="addst">
      <div class="grow"><label>Name</label><input name="name" required></div><div class="grow"><label>Address</label><input name="address" required></div>
      <div><label>Latitude</label><input name="latitude" type="number" step="0.000001" required style="width:130px"></div>
      <div><label>Longitude</label><input name="longitude" type="number" step="0.000001" required style="width:130px"></div><button class="btn">Add station</button></form></div>
    ${sts.map((s) => `<div class="card"><div class="spread"><h2 style="margin:0">${esc(s.name)} ${statusBadge(s.status)}</h2>
        <button class="btn sm ghost" data-toggle="${s.station_id}">${s.status === 'ACTIVE' ? 'Set to maintenance' : 'Set active'}</button></div>
      <p class="muted small">${esc(s.address)} (${s.latitude}, ${s.longitude})</p>
      ${table([['Charger', (r) => `${esc(TYPE_LABEL[r.charger_type] || r.charger_type)} #${r.charger_id}`], ['kW', 'power_kw', 'r'], ['Price / kWh', (r) => money(r.price_per_kwh), 'r'], ['Status', (r) => statusBadge(r.status)]],
        chs.filter((c) => c.station_id === s.station_id), 'No chargers')}
      <form class="row" data-addc="${s.station_id}" style="margin-top:.8rem"><div><label>Type</label><select name="charger_type">${Object.entries(TYPE_LABEL).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
        <div><label>kW</label><input name="power_kw" type="number" step="0.1" required style="width:90px"></div><div><label>Price / kWh</label><input name="price_per_kwh" type="number" step="0.5" required style="width:100px"></div>
        <button class="btn sm">Add charger</button></form></div>`).join('')}`);
  $('#addst').onsubmit = async (e) => {
    e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
    try { await api('/admin/stations', 'POST', { name: f.name, address: f.address, latitude: Number(f.latitude), longitude: Number(f.longitude), status: 'ACTIVE' }); toast('Station added', 'success'); pageStations(); } catch (err) { toast(err.message, 'error'); }
  };
  $app.querySelectorAll('[data-addc]').forEach((fm) => (fm.onsubmit = async (e) => {
    e.preventDefault(); const f = Object.fromEntries(new FormData(fm));
    try { await api(`/admin/stations/${fm.dataset.addc}/chargers`, 'POST', { charger_type: f.charger_type, power_kw: Number(f.power_kw), price_per_kwh: Number(f.price_per_kwh), status: 'ACTIVE' }); toast('Charger added', 'success'); pageStations(); } catch (err) { toast(err.message, 'error'); }
  }));
  $app.querySelectorAll('[data-toggle]').forEach((b) => (b.onclick = async () => {
    const s = sts.find((x) => x.station_id === Number(b.dataset.toggle)); const next = s.status === 'ACTIVE' ? 'MAINTENANCE' : 'ACTIVE';
    if (!(await confirmBox('Change station status', `Set <b>${esc(s.name)}</b> to ${next.toLowerCase()}?`))) return;
    try { await api('/admin/stations/' + s.station_id, 'PUT', { name: s.name, address: s.address, latitude: s.latitude, longitude: s.longitude, status: next }); toast('Station updated', 'success'); pageStations(); } catch (err) { toast(err.message, 'error'); }
  }));
}

async function pageSlots() {
  const chs = await api('/admin/chargers');
  shell('#/slots', `<div class="pagehead"><div><h1>Slots</h1><p class="muted">Create bookable time slots for a charger.</p></div></div>
    <div class="card"><h2>Generate slots</h2><form class="row" id="gen">
      <div class="grow"><label>Charger</label><select name="cid">${chs.map((c) => `<option value="${c.charger_id}">Station ${c.station_id} - ${esc(chargerName(c.charger_type, c.charger_id))}</option>`).join('')}</select></div>
      <div><label>Date</label><input type="date" name="date" required></div>
      <div><label>From hour</label><input type="number" name="start_hour" min="0" max="23" value="6" style="width:90px"></div>
      <div><label>To hour</label><input type="number" name="end_hour" min="1" max="24" value="22" style="width:90px"></div>
      <div><label>Minutes per slot</label><input type="number" name="slot_minutes" min="15" max="240" step="15" value="60" style="width:110px"></div>
      <button class="btn">Generate</button></form>
      <p class="hint">Tip: to demo a charging session, create slots for today including the current hour.</p></div>`);
  $('#gen').onsubmit = async (e) => {
    e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
    try { const r = await api(`/admin/chargers/${f.cid}/slots/generate`, 'POST', { date: f.date, start_hour: Number(f.start_hour), end_hour: Number(f.end_hour), slot_minutes: Number(f.slot_minutes) }); toast(`${r.slots_created} slot(s) created`, 'success'); }
    catch (err) { toast(err.message, 'error'); }
  };
}

route();
