-- =====================================================================
-- EV Charging Station Locator & Booking System
-- 01_schema.sql  -  Tables, constraints, indexes, audit triggers
-- Owner: Raushan (database foundation for FR-08 .. FR-15)
-- Target: MySQL 8.0.16+ (CHECK constraints are enforced from 8.0.16).
-- MariaDB compatibility depends on the installed version and SQL mode.
-- WARNING: This script DROPS and recreates these tables; existing data is lost.
-- It does NOT create or select a database: select one first, or use
-- scripts/install_db.sh or database/00_install_all_in_one.sql, which do it for you.
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS notification;
DROP TABLE IF EXISTS booking_audit;
DROP TABLE IF EXISTS payment;
DROP TABLE IF EXISTS charging_session;
DROP TABLE IF EXISTS booking;
DROP TABLE IF EXISTS charging_slot;
DROP TABLE IF EXISTS charger;
DROP TABLE IF EXISTS charging_station;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS app_setting;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- Business-rule settings (kept in a table so rules are data, not code)
-- ---------------------------------------------------------------------
CREATE TABLE app_setting (
    setting_key   VARCHAR(50) PRIMARY KEY,
    setting_value INT         NOT NULL,
    description   VARCHAR(200)
) ENGINE=InnoDB;

INSERT INTO app_setting VALUES
 ('cancel_cutoff_minutes',   60, 'A booking can be cancelled by its owner only if the slot starts more than this many minutes from now'),
 ('session_early_minutes',   15, 'A charging session may be started at most this many minutes before the slot start time');

-- ---------------------------------------------------------------------
-- users  (FR-01 is Aarya's; this table is the shared foundation)
-- ---------------------------------------------------------------------
CREATE TABLE users (
    user_id       INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL,
    phone         VARCHAR(10)  NOT NULL,                -- exactly 10 digits
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(10)  NOT NULL DEFAULT 'USER',
    is_active     TINYINT(1)   NOT NULL DEFAULT 1,
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    -- Only ONE administrator may exist: admin_flag is 1 for the ADMIN row and NULL for everyone else.
    -- A UNIQUE index allows many NULLs but only one 1, so a second ADMIN row is rejected by the database.
    admin_flag    TINYINT GENERATED ALWAYS AS (CASE WHEN role = 'ADMIN' THEN 1 ELSE NULL END) STORED,
    CONSTRAINT uq_single_admin UNIQUE (admin_flag),
    CONSTRAINT uq_users_email UNIQUE (email),
    CONSTRAINT uq_users_name  UNIQUE (name),   -- the name doubles as a login id (case-insensitive collation)
    CONSTRAINT chk_users_role CHECK (role IN ('USER','ADMIN')),
    CONSTRAINT chk_users_phone CHECK (phone REGEXP '^[0-9]{10}$')
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- charging_station
-- ---------------------------------------------------------------------
CREATE TABLE charging_station (
    station_id INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(120)  NOT NULL,
    address    VARCHAR(255)  NOT NULL,
    latitude   DECIMAL(9,6)  NOT NULL,
    longitude  DECIMAL(9,6)  NOT NULL,
    status     VARCHAR(15)   NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_station_name UNIQUE (name),
    CONSTRAINT chk_station_lat    CHECK (latitude  BETWEEN -90  AND 90),
    CONSTRAINT chk_station_lng    CHECK (longitude BETWEEN -180 AND 180),
    CONSTRAINT chk_station_status CHECK (status IN ('ACTIVE','INACTIVE','MAINTENANCE')),
    INDEX ix_station_location (latitude, longitude),
    INDEX ix_station_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- charger (a physical charging point at a station)
-- ---------------------------------------------------------------------
CREATE TABLE charger (
    charger_id    INT AUTO_INCREMENT PRIMARY KEY,
    station_id    INT           NOT NULL,
    charger_type  VARCHAR(20)   NOT NULL,
    power_kw      DECIMAL(6,2)  NOT NULL,
    price_per_kwh DECIMAL(8,2)  NOT NULL,
    status        VARCHAR(15)   NOT NULL DEFAULT 'ACTIVE',
    CONSTRAINT fk_charger_station FOREIGN KEY (station_id)
        REFERENCES charging_station (station_id) ON DELETE RESTRICT,
    CONSTRAINT chk_charger_type   CHECK (charger_type IN ('CCS2','CHAdeMO','Type2','GBT','AC001')),
    CONSTRAINT chk_charger_power  CHECK (power_kw > 0),
    CONSTRAINT chk_charger_price  CHECK (price_per_kwh >= 0),
    CONSTRAINT chk_charger_status CHECK (status IN ('ACTIVE','INACTIVE','MAINTENANCE')),
    INDEX ix_charger_station (station_id),
    INDEX ix_charger_type (charger_type)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- charging_slot (a bookable time window on one charger)
-- ---------------------------------------------------------------------
CREATE TABLE charging_slot (
    slot_id    INT AUTO_INCREMENT PRIMARY KEY,
    charger_id INT         NOT NULL,
    start_time DATETIME    NOT NULL,
    end_time   DATETIME    NOT NULL,
    status     VARCHAR(15) NOT NULL DEFAULT 'AVAILABLE',
    CONSTRAINT fk_slot_charger FOREIGN KEY (charger_id)
        REFERENCES charger (charger_id) ON DELETE RESTRICT,
    CONSTRAINT uq_slot_charger_start UNIQUE (charger_id, start_time),
    CONSTRAINT chk_slot_time   CHECK (end_time > start_time),
    CONSTRAINT chk_slot_status CHECK (status IN ('AVAILABLE','BOOKED','BLOCKED')),
    INDEX ix_slot_status_start (status, start_time),
    INDEX ix_slot_start (start_time)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- booking
-- active_slot_id is a STORED generated column: it equals slot_id while the
-- booking is "active" (CONFIRMED / IN_PROGRESS) and NULL otherwise.
-- UNIQUE(active_slot_id) therefore means: a slot can have AT MOST ONE active
-- booking, enforced by the database itself. NULLs are not considered equal in a
-- UNIQUE index, so any number of CANCELLED/COMPLETED rows may exist.
-- This is the last line of defence against double booking, even if the
-- application / stored procedure had a bug.
-- ---------------------------------------------------------------------
CREATE TABLE booking (
    booking_id     INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT         NOT NULL,
    slot_id        INT         NOT NULL,
    status         VARCHAR(15) NOT NULL DEFAULT 'CONFIRMED',
    booked_at      TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cancelled_at   DATETIME    NULL,
    battery_start_pct    TINYINT UNSIGNED NULL,      -- battery level of the driver when booking (0-100 percent)
    battery_target_pct   TINYINT UNSIGNED NULL,      -- level the driver wants to reach (0-100 percent)
    battery_capacity_kwh DECIMAL(6,2)     NULL,      -- vehicle battery size
    active_slot_id INT GENERATED ALWAYS AS
        (CASE WHEN status IN ('CONFIRMED','IN_PROGRESS') THEN slot_id ELSE NULL END) STORED,
    CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE RESTRICT,
    CONSTRAINT fk_booking_slot FOREIGN KEY (slot_id) REFERENCES charging_slot (slot_id) ON DELETE RESTRICT,
    CONSTRAINT chk_booking_status CHECK (status IN ('CONFIRMED','IN_PROGRESS','COMPLETED','CANCELLED')),
    CONSTRAINT chk_booking_battery CHECK (
        (battery_start_pct  IS NULL OR battery_start_pct  BETWEEN 0 AND 100) AND
        (battery_target_pct IS NULL OR battery_target_pct BETWEEN 1 AND 100) AND
        (battery_capacity_kwh IS NULL OR battery_capacity_kwh > 0) AND
        (battery_start_pct IS NULL OR battery_target_pct IS NULL OR battery_target_pct > battery_start_pct)),
    CONSTRAINT uq_active_slot UNIQUE (active_slot_id),
    INDEX ix_booking_user (user_id, booked_at),
    INDEX ix_booking_slot (slot_id),
    INDEX ix_booking_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- charging_session  (0 or 1 per booking)
-- ---------------------------------------------------------------------
CREATE TABLE charging_session (
    session_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT           NOT NULL,
    start_time DATETIME      NOT NULL,
    end_time   DATETIME      NULL,
    energy_kwh DECIMAL(8,3)  NULL,
    cost       DECIMAL(10,2) NULL,
    battery_end_pct TINYINT UNSIGNED NULL,   -- estimated battery level when charging finished
    status     VARCHAR(15)   NOT NULL DEFAULT 'ACTIVE',
    CONSTRAINT fk_session_booking FOREIGN KEY (booking_id)
        REFERENCES booking (booking_id) ON DELETE RESTRICT,
    CONSTRAINT uq_session_booking UNIQUE (booking_id),
    CONSTRAINT chk_session_status CHECK (status IN ('ACTIVE','COMPLETED')),
    CONSTRAINT chk_session_energy CHECK (energy_kwh IS NULL OR energy_kwh >= 0),
    CONSTRAINT chk_session_cost   CHECK (cost IS NULL OR cost >= 0),
    CONSTRAINT chk_session_battery CHECK (battery_end_pct IS NULL OR battery_end_pct BETWEEN 0 AND 100),
    CONSTRAINT chk_session_time   CHECK (end_time IS NULL OR end_time >= start_time),
    INDEX ix_session_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- payment (optional scope: one payment record per booking)
-- ---------------------------------------------------------------------
CREATE TABLE payment (
    payment_id      INT AUTO_INCREMENT PRIMARY KEY,
    booking_id      INT           NOT NULL,
    amount          DECIMAL(10,2) NOT NULL,
    status          VARCHAR(15)   NOT NULL DEFAULT 'PENDING',
    transaction_ref VARCHAR(50)   NOT NULL,
    method          VARCHAR(15)   NULL,        -- UPI / CARD / NETBANKING / CASH (set when the user pays)
    paid_at         DATETIME      NULL,
    created_at      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_booking FOREIGN KEY (booking_id)
        REFERENCES booking (booking_id) ON DELETE RESTRICT,
    CONSTRAINT uq_payment_booking UNIQUE (booking_id),
    CONSTRAINT uq_payment_ref UNIQUE (transaction_ref),
    CONSTRAINT chk_payment_amount CHECK (amount >= 0),
    CONSTRAINT chk_payment_status CHECK (status IN ('PENDING','PAID','REFUNDED','FAILED')),
    CONSTRAINT chk_payment_method CHECK (method IS NULL OR method IN ('UPI','CARD','NETBANKING','CASH')),
    CONSTRAINT chk_payment_paid   CHECK (status <> 'PAID' OR (method IS NOT NULL AND paid_at IS NOT NULL))
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- booking_audit: every booking state change is recorded (auditable DB).
-- No foreign key on purpose: audit rows must survive any later clean-up.
-- ---------------------------------------------------------------------
CREATE TABLE booking_audit (
    audit_id   INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT         NOT NULL,
    old_status VARCHAR(15) NULL,
    new_status VARCHAR(15) NOT NULL,
    changed_at TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX ix_audit_booking (booking_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- notification: messages shown to the user (booking confirmed with station name and slot time,
-- cancelled, charging started / complete, payment received). Rows are written by the triggers below,
-- inside the same transaction as the booking itself, so a rolled-back booking never leaves a message.
-- ---------------------------------------------------------------------
CREATE TABLE notification (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT          NOT NULL,
    booking_id INT          NULL,
    type       VARCHAR(15)  NOT NULL,
    title      VARCHAR(120) NOT NULL,
    message    VARCHAR(400) NOT NULL,
    is_read    TINYINT(1)   NOT NULL DEFAULT 0,
    created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE RESTRICT,
    CONSTRAINT chk_notification_type CHECK (type IN ('BOOKED','CANCELLED','CHARGING','COMPLETE','PAYMENT')),
    INDEX ix_notification_user (user_id, is_read, notification_id)
) ENGINE=InnoDB;

DROP TRIGGER IF EXISTS trg_booking_ai;
DROP TRIGGER IF EXISTS trg_booking_au;
DROP TRIGGER IF EXISTS trg_booking_notify_ai;
DROP TRIGGER IF EXISTS trg_booking_notify_au;
DROP TRIGGER IF EXISTS trg_payment_notify_au;

DELIMITER $$
CREATE TRIGGER trg_booking_ai AFTER INSERT ON booking
FOR EACH ROW
BEGIN
    INSERT INTO booking_audit (booking_id, old_status, new_status)
    VALUES (NEW.booking_id, NULL, NEW.status);
END$$

CREATE TRIGGER trg_booking_au AFTER UPDATE ON booking
FOR EACH ROW
BEGIN
    IF NOT (OLD.status <=> NEW.status) THEN
        INSERT INTO booking_audit (booking_id, old_status, new_status)
        VALUES (NEW.booking_id, OLD.status, NEW.status);
    END IF;
END$$

-- Notification triggers ----------------------------------------------------
-- "Booking confirmed": station name, charger and slot timing are put into the message.
CREATE TRIGGER trg_booking_notify_ai AFTER INSERT ON booking
FOR EACH ROW
BEGIN
    DECLARE v_station VARCHAR(120);
    DECLARE v_type    VARCHAR(20);
    DECLARE v_charger INT;
    DECLARE v_start   DATETIME;
    DECLARE v_end     DATETIME;
    IF NEW.status = 'CONFIRMED' THEN
        SELECT st.name, c.charger_type, c.charger_id, s.start_time, s.end_time
          INTO v_station, v_type, v_charger, v_start, v_end
          FROM charging_slot s
          JOIN charger c ON c.charger_id = s.charger_id
          JOIN charging_station st ON st.station_id = c.station_id
         WHERE s.slot_id = NEW.slot_id;
        INSERT INTO notification (user_id, booking_id, type, title, message)
        VALUES (NEW.user_id, NEW.booking_id, 'BOOKED', 'Booking confirmed',
                CONCAT('Your slot at ', v_station, ' (', v_type, ' charger #', v_charger, ') is booked for ',
                       DATE_FORMAT(v_start, '%a %e %b'), ', ', DATE_FORMAT(v_start, '%H:%i'), ' - ',
                       DATE_FORMAT(v_end, '%H:%i'), '. Booking #', NEW.booking_id, '.'));
    END IF;
END$$

CREATE TRIGGER trg_booking_notify_au AFTER UPDATE ON booking
FOR EACH ROW
BEGIN
    DECLARE v_station VARCHAR(120);
    DECLARE v_start   DATETIME;
    DECLARE v_end     DATETIME;
    IF NOT (OLD.status <=> NEW.status) THEN
        SELECT st.name, s.start_time, s.end_time INTO v_station, v_start, v_end
          FROM charging_slot s
          JOIN charger c ON c.charger_id = s.charger_id
          JOIN charging_station st ON st.station_id = c.station_id
         WHERE s.slot_id = NEW.slot_id;
        IF NEW.status = 'CANCELLED' THEN
            INSERT INTO notification (user_id, booking_id, type, title, message)
            VALUES (NEW.user_id, NEW.booking_id, 'CANCELLED', 'Booking cancelled',
                    CONCAT('Your booking #', NEW.booking_id, ' at ', v_station, ' (', DATE_FORMAT(v_start, '%a %e %b'), ', ',
                           DATE_FORMAT(v_start, '%H:%i'), ' - ', DATE_FORMAT(v_end, '%H:%i'), ') was cancelled and the slot is free again.'));
        ELSEIF NEW.status = 'IN_PROGRESS' THEN
            INSERT INTO notification (user_id, booking_id, type, title, message)
            VALUES (NEW.user_id, NEW.booking_id, 'CHARGING', 'Charging started',
                    CONCAT('Charging has started at ', v_station, '. We will tell you when it is complete.'));
        ELSEIF NEW.status = 'COMPLETED' THEN
            INSERT INTO notification (user_id, booking_id, type, title, message)
            VALUES (NEW.user_id, NEW.booking_id, 'COMPLETE', 'Charging complete - slot released',
                    CONCAT('Your vehicle at ', v_station, ' has finished charging. The slot is now free for other drivers. Please pay your bill in My bookings.'));
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_payment_notify_au AFTER UPDATE ON payment
FOR EACH ROW
BEGIN
    DECLARE v_user INT;
    IF NEW.status = 'PAID' AND NOT (OLD.status <=> NEW.status) THEN
        SELECT user_id INTO v_user FROM booking WHERE booking_id = NEW.booking_id;
        INSERT INTO notification (user_id, booking_id, type, title, message)
        VALUES (v_user, NEW.booking_id, 'PAYMENT', 'Payment received',
                CONCAT('We received your payment of Rs. ', FORMAT(NEW.amount, 2), ' for booking #', NEW.booking_id,
                       ' (', NEW.method, '). Reference ', NEW.transaction_ref, '.'));
    END IF;
END$$
DELIMITER ;
