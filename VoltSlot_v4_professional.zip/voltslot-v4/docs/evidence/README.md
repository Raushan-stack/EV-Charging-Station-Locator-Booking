# About these evidence files

The text files in this folder were produced by `scripts/run_all_tests.sh` on the **previous version** of the project
(before 10-digit phone, single administrator, notifications, payment step, battery plan and PDF reports).
They are kept as history. **Run `scripts/run_all_tests.sh root <mysql-password>` again** on your computer to regenerate them
for the current version, then use those fresh files in your report.
