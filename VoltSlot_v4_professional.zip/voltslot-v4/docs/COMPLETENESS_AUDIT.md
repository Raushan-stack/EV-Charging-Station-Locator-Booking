# Completeness audit (current version)

## Verified here (without a database)
| Check | Result |
|-------|--------|
| Every backend file passes `node --check` | yes |
| SQL files: brackets, BEGIN/END, IF/WHILE balanced (structural check) | yes |
| PDF report generator: output validated with `qpdf --check`, rendered and inspected | yes (user report + all-users summary) |
| Both websites run in a real headless browser against a mock API: register/login, 10-digit phone, admin refused on the user site and vice versa, planner, station list, slot grid, booking pop-up with station name and time, bell, bookings page, pay dialog, double-booking page, profile, every admin page, PDF download | yes, no script errors |

## NOT verified (needs your MySQL)
1. **The SQL was not executed.** New schema parts - generated `admin_flag` with UNIQUE, CHECK constraints, three notification triggers, changed views - have not run on MySQL. Install `database/00_install_all_in_one.sql` and send any red error.
2. **Automated tests were not run.** `backend/tests/portal.test.js` (9 new tests) and the updated older tests need MySQL. Run `npm test` in `backend`.
3. **The map** uses Leaflet and OpenStreetMap from the internet. It was not visible in my sandbox (no internet); the offline fallback message was tested. Check it on your computer.
4. **Evidence files** in `docs/evidence/` belong to the previous version. Regenerate with `scripts/run_all_tests.sh`.

## Known limits (be honest in the viva)
* Notifications are **in-app** (pop-up + bell). E-mail / SMS needs an external service and is future scope.
* Payment is **simulated** (no real gateway).
* Distance on the map is a **straight line**; drive time and range use simple assumptions (30 km/h, 6 km per kWh).
* Battery level is entered by the driver; the final level is **calculated** from the energy delivered, not read from the car.
* Report, PPT and certificate for the college are not part of this code.
